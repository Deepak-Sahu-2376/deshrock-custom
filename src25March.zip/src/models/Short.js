import { DataTypes } from 'sequelize';
import { pool } from '../config/database.js';

const Short = {
    create: async (data) => {
        const { propertyId, userId, youtubeVideoId, title, description } = data;
        const query = `
            INSERT INTO "Shorts" 
            ("propertyId", "userId", "youtubeVideoId", "title", "description", "createdAt", "updatedAt")
            VALUES ($1, $2, $3, $4, $5, NOW(), NOW())
            RETURNING *
        `;
        const { rows } = await pool.query(query, [propertyId, userId, youtubeVideoId, title, description]);
        return rows[0];
    },

    findAll: async (where = {}) => {
        let query = `
            SELECT s.*, 
                   p.title as "propertyTitle",
                   u."firstName" as "userFirstName", u."lastName" as "userLastName", u.avatar as "userAvatar"
            FROM "Shorts" s
            JOIN "Properties" p ON s."propertyId" = p.id
            JOIN "Users" u ON s."userId" = u.id
            WHERE s."isActive" = true
        `;
        const params = [];
        if (where.propertyId) {
            query += ` AND s."propertyId" = $1`;
            params.push(where.propertyId);
        }
        query += ` ORDER BY s."createdAt" DESC`;
        const { rows } = await pool.query(query, params);
        return rows;
    },

    findById: async (id) => {
        const query = `
            SELECT s.*, 
                   p.title as "propertyTitle",
                   u."firstName" as "userFirstName", u."lastName" as "userLastName", u.avatar as "userAvatar"
            FROM "Shorts" s
            JOIN "Properties" p ON s."propertyId" = p.id
            JOIN "Users" u ON s."userId" = u.id
            WHERE s.id = $1
        `;
        const { rows } = await pool.query(query, [id]);
        return rows[0];
    },

    delete: async (id) => {
        const query = `DELETE FROM "Shorts" WHERE id = $1 RETURNING *`;
        const { rows } = await pool.query(query, [id]);
        return rows[0];
    },

    incrementViewCount: async (id) => {
        const query = `UPDATE "Shorts" SET "viewCount" = "viewCount" + 1, "updatedAt" = NOW() WHERE id = $1 RETURNING *`;
        const { rows } = await pool.query(query, [id]);
        return rows[0];
    }
};

export default Short;
