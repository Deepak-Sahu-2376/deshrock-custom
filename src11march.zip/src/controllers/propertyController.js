
import db from '../models/index.js';
const { Project: ProjectRepository, CompanyProfile: CompanyProfileRepository, Phase: PhaseRepository, Property: PropertyRepository, User: UserRepository, AgentProfile: AgentProfileRepository, pool } = db;
import { sendTemplateEmail } from '../services/emailService.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { uploadToYouTube } from '../services/youtubeService.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Helper for Pagination
const getPaginationOptions = (page, size) => {
    const limit = size ? +size : 10;
    const offset = page ? page * limit : 0;
    return { limit, offset };
};

// @desc    Get all projects
// @route   GET /api/v1/projects OR /api/v1/properties/projects
const getProjects = async (req, res) => {
    try {
        const { limit, offset } = getPaginationOptions(req.query.page, req.query.size);

        let whereClause = `WHERE "isActive" = true AND "approvalStatus" = 'APPROVED'`;
        const queryParams = [];
        let paramIndex = 1;

        if (req.query.city) {
            whereClause += ` AND "city" ILIKE $${paramIndex}`;
            queryParams.push(`%${req.query.city}%`);
            paramIndex++;
        }

        // Count Query
        const countResult = await pool.query(`SELECT COUNT(*) FROM "Projects" ${whereClause}`, queryParams);
        const totalElements = parseInt(countResult.rows[0].count, 10);

        // Data Query with Joins
        const queryParamsWithPagination = [...queryParams, limit, offset];
        const rowsQuery = `
            SELECT p.*, 
                   json_build_object('id', c.id, 'companyName', c."companyName") as company
            FROM "Projects" p
            LEFT JOIN "CompanyProfiles" c ON p."companyId" = c.id
            ${whereClause}
            ORDER BY p."createdAt" DESC
            LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
        `;

        const { rows } = await pool.query(rowsQuery, queryParamsWithPagination);

        // Transform data
        const projects = rows.map(project => {
            project.mediaFiles = (project.media || []).map(m => ({ ...m, mediaUrl: m.url }));
            return project;
        });

        res.status(200).json({
            success: true,
            content: projects,
            data: {
                content: projects,
                projects: projects,
                totalPages: Math.ceil(totalElements / limit),
                totalElements
            }
        });
    } catch (error) {
        console.error('Error fetching projects:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get all projects (Admin - includes inactive)
// @route   GET /api/v1/properties/projects/view
const getAdminProjects = async (req, res) => {
    try {
        const { limit, offset } = getPaginationOptions(req.query.page, req.query.size);

        const countResult = await pool.query(`SELECT COUNT(*) FROM "Projects" WHERE "approvalStatus" = 'APPROVED'`);
        const totalElements = parseInt(countResult.rows[0].count, 10);

        const rowsQuery = `
            SELECT p.*, 
                   json_build_object('id', c.id, 'companyName', c."companyName") as company
            FROM "Projects" p
            LEFT JOIN "CompanyProfiles" c ON p."companyId" = c.id
            WHERE p."approvalStatus" = 'APPROVED'
            ORDER BY p."createdAt" DESC
            LIMIT $1 OFFSET $2
        `;
        const { rows } = await pool.query(rowsQuery, [limit, offset]);

        const projects = rows.map(project => {
            project.mediaFiles = (project.media || []).map(m => ({ ...m, mediaUrl: m.url }));
            return project;
        });

        res.status(200).json({
            success: true,
            content: projects,
            data: {
                content: projects,
                projects: projects,
                totalPages: Math.ceil(totalElements / limit),
                totalElements
            }
        });
    } catch (error) {
        console.error('Error fetching admin projects:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get Featured Properties
// @route   GET /api/v1/public/properties/featured
const getFeaturedProperties = async (req, res) => {
    try {
        const rowsQuery = `
            SELECT p.*, 
                   json_build_object('companyName', c."companyName") as company
            FROM "Properties" p
            LEFT JOIN "CompanyProfiles" c ON p."companyId" = c.id
            WHERE p."isFeatured" = true AND p.status = 'APPROVED'
            ORDER BY p."createdAt" DESC
            LIMIT 6
        `;
        const { rows: properties } = await pool.query(rowsQuery);

        res.status(200).json({
            success: true,
            content: properties,
            data: { content: properties }
        });
    } catch (error) {
        console.error('Error fetching featured properties:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get Top Featured Properties
// @route   GET /api/v1/public/properties/featured/top
const getFeaturedPropertiesTop = async (req, res) => {
    try {
        const rowsQuery = `
            SELECT p.*, 
                   json_build_object('companyName', c."companyName") as company
            FROM "Properties" p
            LEFT JOIN "CompanyProfiles" c ON p."companyId" = c.id
            WHERE p."isFeatured" = true AND p.status = 'APPROVED'
            ORDER BY p."viewCount" DESC NULLS LAST
            LIMIT 3
        `;
        const { rows: properties } = await pool.query(rowsQuery);

        res.status(200).json({
            success: true,
            data: properties
        });
    } catch (error) {
        console.error('Error fetching top properties:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get All Public Properties
// @route   GET /api/v1/public/properties
const getProperties = async (req, res) => {
    try {
        const { limit, offset } = getPaginationOptions(req.query.page, req.query.size || 12);

        let whereClause = `WHERE p.status = 'APPROVED'`;
        const queryParams = [];
        let paramIndex = 1;

        if (req.query.propertyType) {
            whereClause += ` AND p."propertyType" = $${paramIndex}`;
            queryParams.push(req.query.propertyType);
            paramIndex++;
        }
        if (req.query.listingType) {
            whereClause += ` AND p."listingType" = $${paramIndex}`;
            queryParams.push(req.query.listingType);
            paramIndex++;
        }
        if (req.query.city) {
            whereClause += ` AND p.city ILIKE $${paramIndex}`;
            queryParams.push(`%${req.query.city}%`);
            paramIndex++;
        }

        const countResult = await pool.query(`SELECT COUNT(*) FROM "Properties" p ${whereClause}`, queryParams);
        const totalElements = parseInt(countResult.rows[0].count, 10);

        const rowsQuery = `
            SELECT p.*, 
                   json_build_object('companyName', c."companyName") as company,
                   json_build_object('firstName', u."firstName", 'lastName', u."lastName", 'email', u.email) as user
            FROM "Properties" p
            LEFT JOIN "CompanyProfiles" c ON p."companyId" = c.id
            LEFT JOIN "Users" u ON p."userId" = u.id
            ${whereClause}
            ORDER BY p."createdAt" DESC
            LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
        `;
        const { rows } = await pool.query(rowsQuery, [...queryParams, limit, offset]);

        res.status(200).json({
            success: true,
            content: rows,
            data: {
                content: rows,
                totalPages: Math.ceil(totalElements / limit),
                totalElements
            }
        });
    } catch (error) {
        console.error('Error fetching properties:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get Pending Properties (Admin)
// @route   GET /api/v1/properties/pending-verification
const getPendingProperties = async (req, res) => {
    try {
        const { limit, offset } = getPaginationOptions(req.query.page, req.query.size);

        const countResult = await pool.query(`SELECT COUNT(*) FROM "Properties" WHERE status = 'PENDING'`);
        const totalElements = parseInt(countResult.rows[0].count, 10);

        const rowsQuery = `
            SELECT p.*, 
                   json_build_object('id', c.id, 'companyName', c."companyName") as company,
                   json_build_object('firstName', u."firstName", 'lastName', u."lastName", 'email', u.email) as user
            FROM "Properties" p
            LEFT JOIN "CompanyProfiles" c ON p."companyId" = c.id
            LEFT JOIN "Users" u ON p."userId" = u.id
            WHERE p.status = 'PENDING'
            ORDER BY p."createdAt" ASC
            LIMIT $1 OFFSET $2
        `;
        const { rows } = await pool.query(rowsQuery, [limit, offset]);

        res.status(200).json({
            success: true,
            content: rows,
            data: {
                content: rows,
                totalPages: Math.ceil(totalElements / limit),
                totalElements
            }
        });
    } catch (error) {
        console.error('Error fetching pending properties:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get Pending Projects (Admin)
// @route   GET /api/v1/properties/projects/pending
const getAdminPendingProjects = async (req, res) => {
    try {
        const { limit, offset } = getPaginationOptions(req.query.page, req.query.size);

        const countResult = await pool.query(`SELECT COUNT(*) FROM "Projects" WHERE "approvalStatus" = 'PENDING'`);
        const totalElements = parseInt(countResult.rows[0].count, 10);

        const rowsQuery = `
            SELECT p.*, 
                   json_build_object('id', c.id, 'companyName', c."companyName") as company
            FROM "Projects" p
            LEFT JOIN "CompanyProfiles" c ON p."companyId" = c.id
            WHERE p."approvalStatus" = 'PENDING'
            ORDER BY p."createdAt" ASC
            LIMIT $1 OFFSET $2
        `;
        const { rows } = await pool.query(rowsQuery, [limit, offset]);

        const projects = rows.map(project => {
            project.mediaFiles = (project.media || []).map(m => ({ ...m, mediaUrl: m.url }));
            return project;
        });

        res.status(200).json({
            success: true,
            data: {
                projects: projects,
                content: projects,
                totalPages: Math.ceil(totalElements / limit),
                totalElements
            }
        });
    } catch (error) {
        console.error('Error fetching pending projects:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Approve Property
// @route   POST /api/v1/properties/:id/approve
const approveProperty = async (req, res) => {
    try {
        const property = await PropertyRepository.findById(req.params.id);
        if (!property) {
            return res.status(404).json({ success: false, message: 'Property not found' });
        }

        await pool.query(`UPDATE "Properties" SET status = 'APPROVED', "updatedAt" = NOW() WHERE id = $1`, [property.id]);

        let userToEmail = null;
        if (property.userId) {
            const userRes = await pool.query('SELECT * FROM "Users" WHERE id = $1', [property.userId]);
            if (userRes.rows.length > 0) userToEmail = userRes.rows[0];
        } else if (property.companyId) {
            const companyRes = await pool.query('SELECT "userId" FROM "CompanyProfiles" WHERE id = $1', [property.companyId]);
            if (companyRes.rows.length > 0) {
                const userRes = await pool.query('SELECT * FROM "Users" WHERE id = $1', [companyRes.rows[0].userId]);
                if (userRes.rows.length > 0) userToEmail = userRes.rows[0];
            }
        }

        if (userToEmail) {
            const listData = {
                userName: userToEmail.firstName,
                propertyTitle: property.title,
                propertyId: property.id,
                location: property.city,
                propertyType: property.propertyType,
                price: property.basePrice,
                viewLink: `${process.env.CLIENT_URL}/property/${property.id}`
            };
            sendTemplateEmail(userToEmail.email, 'PROPERTY_LISTED', listData).catch(console.error);
        }

        res.status(200).json({ success: true, message: 'Property approved successfully' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Reject Property
// @route   POST /api/v1/properties/:id/reject
const rejectProperty = async (req, res) => {
    try {
        const { reason } = req.body;
        const propertyId = req.params.id;
        const result = await pool.query(
            `UPDATE "Properties" SET status = 'REJECTED', "rejectionReason" = $1, "updatedAt" = NOW() WHERE id = $2 RETURNING id`,
            [reason, propertyId]
        );

        if (result.rowCount === 0) {
            return res.status(404).json({ success: false, message: 'Property not found' });
        }

        res.status(200).json({ success: true, message: 'Property rejected' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Approve Project
// @route   POST /api/v1/projects/view/:projectId/approve (Mapped in admin routes/property routes)
const approveProject = async (req, res) => {
    try {
        const { projectId } = req.params;
        const result = await pool.query(
            `UPDATE "Projects" SET "isActive" = true, "approvalStatus" = 'APPROVED', "updatedAt" = NOW() WHERE id = $1 RETURNING id`,
            [projectId]
        );

        if (result.rowCount === 0) {
            return res.status(404).json({ success: false, message: 'Project not found' });
        }

        res.status(200).json({ success: true, message: 'Project approved' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Reject Project
// @route   POST /api/v1/projects/view/:projectId/reject
const rejectProject = async (req, res) => {
    try {
        const { projectId } = req.params;
        const result = await pool.query(
            `UPDATE "Projects" SET "isActive" = false, "approvalStatus" = 'REJECTED', "updatedAt" = NOW() WHERE id = $1 RETURNING id`,
            [projectId]
        );

        if (result.rowCount === 0) {
            return res.status(404).json({ success: false, message: 'Project not found' });
        }

        res.status(200).json({ success: true, message: 'Project rejected' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Create Project Phase
// @route   POST /api/v1/projects/:projectId/phases
const createPhase = async (req, res) => {
    try {
        const { projectId } = req.params;
        const project = await ProjectRepository.findById(projectId);
        if (!project) {
            return res.status(404).json({ success: false, message: 'Project not found' });
        }

        // Handle FormData vs JSON
        let phaseData = req.body;
        if (req.body.phase) {
            try {
                phaseData = JSON.parse(req.body.phase);
            } catch (e) {
                return res.status(400).json({ success: false, message: 'Invalid phase data format' });
            }
        }

        // Process Files
        const files = req.files || {};
        const logoFile = files['logoFile'] ? files['logoFile'][0] : null;
        const brochureFile = files['brochureFile'] ? files['brochureFile'][0] : null;
        const masterPlanFile = files['masterPlanFile'] ? files['masterPlanFile'][0] : null;
        const floorPlanFiles = files['floorPlanFiles'] || [];

        // Map file paths
        const phaseLogoUrl = logoFile ? `/uploads/documents/${logoFile.filename}` : null;
        const phaseBrochureUrl = brochureFile ? `/uploads/documents/${brochureFile.filename}` : null;
        const masterPlanUrl = masterPlanFile ? `/uploads/documents/${masterPlanFile.filename}` : null;
        const floorPlanUrls = floorPlanFiles.map(f => `/uploads/documents/${f.filename}`);

        const newPhase = await PhaseRepository.create({
            ...phaseData,
            projectId: projectId,
            phaseLogoUrl,
            phaseBrochureUrl,
            masterPlanUrl,
            floorPlanUrls
        });

        res.status(201).json({
            success: true,
            message: "Phase created successfully",
            data: newPhase
        });
    } catch (error) {
        console.error('Error creating phase:', error);
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Create Property
// @route   POST /api/v1/properties/create
const createProperty = async (req, res) => {
    try {
        if (!req.body.property) {
            return res.status(400).json({ success: false, message: 'Property data is missing' });
        }

        const propertyData = JSON.parse(req.body.property);
        const files = req.files || {};

        const imageFiles = files['images'] || [];
        const floorPlanFile = files['floorPlan'] ? files['floorPlan'][0] : null;
        const videoFile = files['video'] ? files['video'][0] : null;

        const imageUrls = imageFiles.map(file => `/uploads/documents/${file.filename}`);
        const floorPlanUrl = floorPlanFile ? `/uploads/documents/${floorPlanFile.filename}` : null;

        let videoUrl = propertyData.video || null;
        let localVideoPath = null;
        let videoFileToUpload = null;

        if (videoFile) {
            videoUrl = `/uploads/documents/${videoFile.filename}`;
            localVideoPath = videoFile.path;
            videoFileToUpload = videoFile;
        }

        if (req.user.userType === 'buyer') {
            if (propertyData.listingType === 'SALE') {
                return res.status(403).json({ success: false, message: 'Buyers can only post properties for Rent.' });
            }
        }

        const companyProfileRes = await pool.query('SELECT id FROM "CompanyProfiles" WHERE "userId" = $1', [req.user.id]);
        const companyProfile = companyProfileRes.rows[0];

        let companyId = null;
        let initialStatus = 'PENDING';

        if (req.user.userType === 'company_agent') {
            const agentProfileRes = await pool.query('SELECT "companyId" FROM "AgentProfiles" WHERE "userId" = $1', [req.user.id]);
            const agentProfile = agentProfileRes.rows[0];
            if (!agentProfile) {
                return res.status(403).json({ success: false, message: 'Agent profile not found' });
            }
            companyId = agentProfile.companyId;
            initialStatus = 'PENDING_COMPANY';
        } else if (companyProfile) {
            companyId = companyProfile.id;
            initialStatus = 'PENDING';
        }

        const newProperty = await PropertyRepository.create({
            ...propertyData,
            companyId: companyId,
            userId: req.user.id,
            images: imageUrls,
            floorPlan: floorPlanUrl,
            video: videoUrl,
            status: initialStatus
        });

        // Send Email
        const subData = {
            userName: req.user.firstName,
            propertyTitle: newProperty.title,
            location: newProperty.city || 'Location',
            submittedDate: new Date().toLocaleString()
        };
        sendTemplateEmail(req.user.email, 'PROPERTY_SUBMITTED', subData).catch(console.error);

        res.status(201).json({
            success: true,
            message: 'Property created successfully',
            data: newProperty
        });

        // Background YouTube Upload
        if (videoFileToUpload && localVideoPath) {
            (async () => {
                try {
                    console.log('Starting background YouTube upload...');
                    const videoId = await uploadToYouTube(
                        localVideoPath,
                        propertyData.title || 'Property Video',
                        propertyData.description || 'Property Video Description'
                    );

                    if (videoId) {
                        const youtubeUrl = `https://www.youtube.com/watch?v=${videoId}`;
                        console.log('Background upload successful. Updating property with URL:', youtubeUrl);

                        await pool.query(`UPDATE "Properties" SET video = $1 WHERE id = $2`, [youtubeUrl, newProperty.id]);

                        fs.unlink(localVideoPath, (err) => {
                            if (err) console.error('Error deleting local video file:', err);
                            else console.log('Local video file deleted after YouTube upload.');
                        });
                    }
                } catch (bgError) {
                    console.error('Background YouTube upload failed:', bgError);
                }
            })();
        }

    } catch (error) {
        console.error('Error creating property:', error);
        console.error('Stack:', error.stack);
        res.status(500).json({ success: false, message: error.message || 'Internal Server Error' });
    }
};

// @desc    Get Property By ID (Public)
// @route   GET /api/v1/public/properties/:id
const getPropertyById = async (req, res) => {
    try {
        const propertyId = req.params.id;
        const property = await PropertyRepository.findById(propertyId);

        if (!property) {
            return res.status(404).json({ success: false, message: 'Property not found' });
        }

        // Fetch related data
        if (property.companyId) {
            const companyRes = await pool.query('SELECT id, "companyName", website FROM "CompanyProfiles" WHERE id = $1', [property.companyId]);
            property.company = companyRes.rows[0];
        }

        if (property.userId) {
            const userRes = await pool.query('SELECT email, phone, "firstName", "lastName" FROM "Users" WHERE id = $1', [property.userId]);
            property.user = userRes.rows[0];
            if (property.company && userRes.rows[0]) property.company.user = userRes.rows[0];
        }

        if (property.status !== 'APPROVED') {
            let isAuthorized = false;

            if (req.user) {
                if (req.user.userType === 'admin') {
                    isAuthorized = true;
                } else if (req.user.id === property.userId) {
                    isAuthorized = true;
                } else if (req.user.userType === 'company') {
                    const reqCompanyRes = await pool.query('SELECT id FROM "CompanyProfiles" WHERE "userId" = $1', [req.user.id]);
                    if (reqCompanyRes.rows.length > 0 && property.companyId === reqCompanyRes.rows[0].id) {
                        isAuthorized = true;
                    }
                }
            }

            if (!isAuthorized) {
                return res.status(404).json({ success: false, message: 'Property not found' });
            }
        }

        const newViewCount = (property.viewCount || 0) + 1;
        await pool.query('UPDATE "Properties" SET "viewCount" = $1 WHERE id = $2', [newViewCount, propertyId]);
        property.viewCount = newViewCount;

        res.status(200).json({
            success: true,
            data: property
        });
    } catch (error) {
        console.error('Error fetching property details:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get Company Projects (My Projects)
// @route   GET /api/v1/properties/projects/view/my-company
const getCompanyProjects = async (req, res) => {
    try {
        const { limit, offset } = getPaginationOptions(req.query.page, req.query.size);

        let companyId;

        if (req.user.userType === 'company') {
            const companyRes = await pool.query('SELECT id FROM "CompanyProfiles" WHERE "userId" = $1', [req.user.id]);
            if (companyRes.rows.length === 0) {
                return res.status(404).json({ success: false, message: 'Company profile not found' });
            }
            companyId = companyRes.rows[0].id;
        } else if (req.user.userType === 'company_agent') {
            const agentRes = await pool.query('SELECT "companyId" FROM "AgentProfiles" WHERE "userId" = $1', [req.user.id]);
            if (agentRes.rows.length === 0) {
                return res.status(404).json({ success: false, message: 'Agent profile not found' });
            }
            companyId = agentRes.rows[0].companyId;
            if (!companyId) {
                return res.status(403).json({ success: false, message: 'Company ID not found for agent' });
            }
        } else {
            return res.status(403).json({ success: false, message: 'Not authorized' });
        }

        const countResult = await pool.query(`SELECT COUNT(*) FROM "Projects" WHERE "companyId" = $1`, [companyId]);
        const totalElements = parseInt(countResult.rows[0].count, 10);

        const rowsQuery = `
            SELECT p.*, 
                   json_build_object('id', c.id, 'companyName', c."companyName") as company
            FROM "Projects" p
            LEFT JOIN "CompanyProfiles" c ON p."companyId" = c.id
            WHERE p."companyId" = $1
            ORDER BY p."createdAt" DESC
            LIMIT $2 OFFSET $3
        `;
        const { rows } = await pool.query(rowsQuery, [companyId, limit, offset]);

        const projects = rows.map(project => {
            project.mediaFiles = (project.media || []).map(m => ({ ...m, mediaUrl: m.url }));
            return project;
        });

        res.status(200).json({
            success: true,
            data: {
                projects: projects,
                content: projects,
                totalPages: Math.ceil(totalElements / limit),
                totalElements
            }
        });

    } catch (error) {
        console.error('Error fetching company projects:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get Company Pending Properties (For Company Admin)
// @route   GET /api/v1/properties/company/pending
const getCompanyPendingProperties = async (req, res) => {
    try {
        const { limit, offset } = getPaginationOptions(req.query.page, req.query.size);

        const companyRes = await pool.query('SELECT id FROM "CompanyProfiles" WHERE "userId" = $1', [req.user.id]);
        if (companyRes.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'Company profile not found' });
        }
        const companyId = companyRes.rows[0].id;

        const countResult = await pool.query(`SELECT COUNT(*) FROM "Properties" WHERE "companyId" = $1 AND status = 'PENDING_COMPANY'`, [companyId]);
        const totalElements = parseInt(countResult.rows[0].count, 10);

        const rowsQuery = `
            SELECT p.*, 
                   json_build_object('id', c.id, 'companyName', c."companyName") as company,
                   json_build_object('id', u.id, 'firstName', u."firstName", 'lastName', u."lastName", 'email', u.email) as user
            FROM "Properties" p
            LEFT JOIN "CompanyProfiles" c ON p."companyId" = c.id
            LEFT JOIN "Users" u ON p."userId" = u.id
            WHERE p."companyId" = $1 AND p.status = 'PENDING_COMPANY'
            ORDER BY p."createdAt" DESC
            LIMIT $2 OFFSET $3
        `;
        const { rows } = await pool.query(rowsQuery, [companyId, limit, offset]);

        res.status(200).json({
            success: true,
            data: {
                content: rows,
                totalPages: Math.ceil(totalElements / limit),
                totalElements
            }
        });

    } catch (error) {
        console.error('Error fetching pending company properties:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Approve Company Property (Company Admin)
// @route   POST /api/v1/properties/:id/company-approve
const approveCompanyProperty = async (req, res) => {
    try {
        const propertyId = req.params.id;
        const property = await PropertyRepository.findById(propertyId);

        if (!property) {
            return res.status(404).json({ success: false, message: 'Property not found' });
        }

        const companyRes = await pool.query('SELECT id FROM "CompanyProfiles" WHERE "userId" = $1', [req.user.id]);
        if (companyRes.rows.length === 0 || property.companyId !== companyRes.rows[0].id) {
            return res.status(403).json({ success: false, message: 'Not authorized to approve this property' });
        }

        if (property.status !== 'PENDING_COMPANY') {
            return res.status(400).json({ success: false, message: 'Property is not in pending company status' });
        }

        await pool.query(`UPDATE "Properties" SET status = 'PENDING', "updatedAt" = NOW() WHERE id = $1`, [propertyId]);

        res.status(200).json({ success: true, message: 'Property approved by company' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Reject Company Property (Company Admin)
// @route   POST /api/v1/properties/:id/company-reject
const rejectCompanyProperty = async (req, res) => {
    try {
        const { reason } = req.body;
        const propertyId = req.params.id;
        const property = await PropertyRepository.findById(propertyId);

        if (!property) {
            return res.status(404).json({ success: false, message: 'Property not found' });
        }

        const companyRes = await pool.query('SELECT id FROM "CompanyProfiles" WHERE "userId" = $1', [req.user.id]);
        if (companyRes.rows.length === 0 || property.companyId !== companyRes.rows[0].id) {
            return res.status(403).json({ success: false, message: 'Not authorized to reject this property' });
        }

        await pool.query(`UPDATE "Properties" SET status = 'REJECTED', "rejectionReason" = $1, "updatedAt" = NOW() WHERE id = $2`, [reason, propertyId]);

        res.status(200).json({ success: true, message: 'Property rejected by company' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get All Company Properties (My Properties)
// @route   GET /api/v1/properties/company/all
const getCompanyProperties = async (req, res) => {
    try {
        const { limit, offset } = getPaginationOptions(req.query.page, req.query.size);
        const status = req.query.status;

        let companyId;
        if (req.user.userType === 'company') {
            const companyRes = await pool.query('SELECT id FROM "CompanyProfiles" WHERE "userId" = $1', [req.user.id]);
            if (companyRes.rows.length === 0) return res.status(404).json({ success: false, message: 'Company profile not found' });
            companyId = companyRes.rows[0].id;
        } else if (req.user.userType === 'company_agent') {
            const agentRes = await pool.query('SELECT "companyId" FROM "AgentProfiles" WHERE "userId" = $1', [req.user.id]);
            if (agentRes.rows.length === 0) return res.status(404).json({ success: false, message: 'Agent profile not found' });
            companyId = agentRes.rows[0].companyId;
        } else {
            return res.status(403).json({ success: false, message: 'Not authorized' });
        }

        let whereClause = `WHERE p."companyId" = $1`;
        const queryParams = [companyId];
        let paramIndex = 2;

        if (status) {
            whereClause += ` AND p.status = $${paramIndex}`;
            queryParams.push(status);
            paramIndex++;
        }

        const countResult = await pool.query(`SELECT COUNT(*) FROM "Properties" p ${whereClause}`, queryParams);
        const totalElements = parseInt(countResult.rows[0].count, 10);

        const rowsQuery = `
            SELECT p.*, 
                   json_build_object('companyName', c."companyName") as company,
                   json_build_object('id', u.id, 'firstName', u."firstName", 'lastName', u."lastName", 'email', u.email) as user
            FROM "Properties" p
            LEFT JOIN "CompanyProfiles" c ON p."companyId" = c.id
            LEFT JOIN "Users" u ON p."userId" = u.id
            ${whereClause}
            ORDER BY p."createdAt" DESC
            LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
        `;
        const { rows } = await pool.query(rowsQuery, [...queryParams, limit, offset]);

        res.status(200).json({
            success: true,
            data: {
                content: rows,
                totalPages: Math.ceil(totalElements / limit),
                totalElements
            }
        });

    } catch (error) {
        console.error('Error fetching company properties:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Update Property (Admin/Owner)
// @route   PUT /api/v1/properties/:id
const updateProperty = async (req, res) => {
    try {
        const propertyId = req.params.id;
        let property = await PropertyRepository.findById(propertyId);

        if (!property) {
            return res.status(404).json({ success: false, message: 'Property not found' });
        }

        // Authorization: Admin or Owner (User or Company Agent owning it)
        let isAuthorized = false;
        if (req.user.userType === 'admin') {
            isAuthorized = true;
        } else if (req.user.id === property.userId) {
            isAuthorized = true;
        } else if (req.user.userType === 'company_agent') {
            const agentRes = await pool.query('SELECT "companyId" FROM "AgentProfiles" WHERE "userId" = $1', [req.user.id]);
            if (agentRes.rows.length > 0 && agentRes.rows[0].companyId === property.companyId) {
                isAuthorized = true;
            }
        } else if (req.user.userType === 'company') {
            const companyRes = await pool.query('SELECT id FROM "CompanyProfiles" WHERE "userId" = $1', [req.user.id]);
            if (companyRes.rows.length > 0 && companyRes.rows[0].id === property.companyId) {
                isAuthorized = true;
            }
        }

        if (!isAuthorized) {
            return res.status(403).json({ success: false, message: 'Not authorized to update this property' });
        }

        let updates = req.body;
        if (req.body.property) {
            try {
                updates = JSON.parse(req.body.property);
            } catch (e) {
                return res.status(400).json({ success: false, message: 'Invalid property data' });
            }
        }

        const allowedFields = ['title', 'description', 'price', 'basePrice', 'city', 'address', 'latitude', 'longitude', 'propertyType', 'listingType', 'bedrooms', 'bathrooms', 'area', 'status'];
        const sqlUpdates = [];
        const sqlValues = [];
        let paramIndex = 1;

        Object.keys(updates).forEach(key => {
            if (allowedFields.includes(key)) {
                sqlUpdates.push(`"${key}" = $${paramIndex}`);
                sqlValues.push(updates[key]);
                paramIndex++;
            }
        });

        if (req.user.userType === 'admin' && updates.status) {
            if (!sqlUpdates.some(u => u.startsWith('"status"'))) {
                sqlUpdates.push(`"status" = $${paramIndex}`);
                sqlValues.push(updates.status);
                paramIndex++;
            } else {
                const index = sqlUpdates.findIndex(u => u.startsWith('"status"'));
                sqlValues[index] = updates.status;
            }
        }

        // --- Media Handling ---
        let imagesChanged = false;
        let currentImages = property.images || [];

        if (req.body.imagesToDelete) {
            const toDelete = Array.isArray(req.body.imagesToDelete) ? req.body.imagesToDelete : [req.body.imagesToDelete];
            const newImages = [];
            currentImages.forEach(url => {
                if (toDelete.includes(url)) {
                    try {
                        const safePath = url.startsWith('/') ? url.substring(1) : url;
                        const absolutePath = path.join(process.cwd(), safePath);
                        if (fs.existsSync(absolutePath)) {
                            fs.unlinkSync(absolutePath);
                        }
                    } catch (e) {
                        console.error(`Failed to delete image ${url}:`, e);
                    }
                    imagesChanged = true;
                } else {
                    newImages.push(url);
                }
            });
            currentImages = newImages;
        }

        if (req.files && req.files['images']) {
            req.files['images'].forEach(file => {
                currentImages.push(`/uploads/documents/${file.filename}`);
            });
            imagesChanged = true;
        }

        if (imagesChanged) {
            sqlUpdates.push(`"images" = $${paramIndex}`);
            // ARRAY format literal for postgres, or just JSON stringified depending on column type but schema says text[] so we pass array
            sqlValues.push(currentImages);
            paramIndex++;
        }

        let floorPlanUrl = property.floorPlan;
        if (req.files && req.files['floorPlan'] && req.files['floorPlan'][0]) {
            if (floorPlanUrl) {
                try {
                    const safePath = floorPlanUrl.startsWith('/') ? floorPlanUrl.substring(1) : floorPlanUrl;
                    const absolutePath = path.join(process.cwd(), safePath);
                    if (fs.existsSync(absolutePath)) fs.unlinkSync(absolutePath);
                } catch (e) { }
            }
            floorPlanUrl = `/uploads/documents/${req.files['floorPlan'][0].filename}`;
            sqlUpdates.push(`"floorPlan" = $${paramIndex}`);
            sqlValues.push(floorPlanUrl);
            paramIndex++;
        }

        let videoUrl = property.video;
        if (req.files && req.files['video'] && req.files['video'][0]) {
            if (videoUrl) {
                try {
                    const safePath = videoUrl.startsWith('/') ? videoUrl.substring(1) : videoUrl;
                    const absolutePath = path.join(process.cwd(), safePath);
                    if (fs.existsSync(absolutePath)) fs.unlinkSync(absolutePath);
                } catch (e) { }
            }
            videoUrl = `/uploads/documents/${req.files['video'][0].filename}`;
            sqlUpdates.push(`"video" = $${paramIndex}`);
            sqlValues.push(videoUrl);
            paramIndex++;
        }

        if (sqlUpdates.length > 0) {
            sqlUpdates.push(`"updatedAt" = NOW()`);
            sqlValues.push(propertyId);
            const updateQuery = `UPDATE "Properties" SET ${sqlUpdates.join(', ')} WHERE id = $${paramIndex} RETURNING *`;
            const updated = await pool.query(updateQuery, sqlValues);
            property = updated.rows[0];
        }

        res.status(200).json({ success: true, message: 'Property updated successfully', data: property });

    } catch (error) {
        console.error('Error updating property:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get Agent Properties
// @route   GET /api/v1/properties/agent/:id
const getAgentProperties = async (req, res) => {
    try {
        const { limit, offset } = getPaginationOptions(req.query.page, req.query.size);
        const agentId = req.params.id;

        if (req.user.id != agentId && req.user.userType !== 'admin' && req.user.userType !== 'company') {
            if (req.user.id.toString() !== agentId.toString()) {
                return res.status(403).json({ success: false, message: 'Not authorized to view these properties' });
            }
        }

        const countResult = await pool.query(`SELECT COUNT(*) FROM "Properties" WHERE "userId" = $1`, [agentId]);
        const totalElements = parseInt(countResult.rows[0].count, 10);

        const rowsQuery = `
            SELECT p.*, 
                   json_build_object('companyName', c."companyName") as company
            FROM "Properties" p
            LEFT JOIN "CompanyProfiles" c ON p."companyId" = c.id
            WHERE p."userId" = $1
            ORDER BY p."createdAt" DESC
            LIMIT $2 OFFSET $3
        `;
        const { rows } = await pool.query(rowsQuery, [agentId, limit, offset]);

        res.status(200).json({
            success: true,
            data: {
                content: rows,
                totalPages: Math.ceil(totalElements / limit),
                totalElements
            }
        });

    } catch (error) {
        console.error('Error fetching agent properties:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

const deleteProperty = async (req, res) => {
    try {
        const propertyId = req.params.id;
        const property = await PropertyRepository.findById(propertyId);
        if (!property) {
            return res.status(404).json({ success: false, message: 'Property not found' });
        }

        let isAuthorized = false;
        if (req.user.userType === 'admin') {
            isAuthorized = true;
        } else if (req.user.id === property.userId) {
            isAuthorized = true;
        } else if (req.user.userType === 'company') {
            const companyRes = await pool.query('SELECT id FROM "CompanyProfiles" WHERE "userId" = $1', [req.user.id]);
            if (companyRes.rows.length > 0 && companyRes.rows[0].id === property.companyId) isAuthorized = true;
        }

        if (!isAuthorized) {
            return res.status(403).json({ success: false, message: 'Not authorized to delete this property' });
        }

        const filesToDelete = [];
        if (property.images && Array.isArray(property.images)) {
            filesToDelete.push(...property.images);
        }
        if (property.floorPlan) filesToDelete.push(property.floorPlan);
        if (property.video) filesToDelete.push(property.video);

        filesToDelete.forEach(filePath => {
            if (filePath) {
                try {
                    const safePath = filePath.startsWith('/') ? filePath.substring(1) : filePath;
                    const absolutePath = path.join(process.cwd(), safePath);
                    if (fs.existsSync(absolutePath)) {
                        fs.unlinkSync(absolutePath);
                        console.log(`Deleted file: ${absolutePath}`);
                    }
                } catch (e) {
                    console.error(`Failed to delete file ${filePath}:`, e);
                }
            }
        });

        await pool.query('DELETE FROM "Inquiries" WHERE "propertyId" = $1', [propertyId]);
        await pool.query('DELETE FROM "Visits" WHERE "propertyId" = $1', [propertyId]);
        await pool.query('DELETE FROM "Properties" WHERE id = $1', [propertyId]);

        res.status(200).json({ success: true, message: 'Property deleted successfully' });

    } catch (error) {
        console.error('Error deleting property:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

export {
    getProjects,
    getAdminProjects,
    getFeaturedProperties,
    getFeaturedPropertiesTop,
    getProperties,
    getPendingProperties,
    approveProperty,
    rejectProperty,
    approveProject,
    rejectProject,
    createPhase,
    createProperty,
    getPropertyById,
    getCompanyProjects,
    getAdminPendingProjects,
    getCompanyPendingProperties,
    approveCompanyProperty,
    rejectCompanyProperty,
    getCompanyProperties,
    getAgentProperties,
    updateProperty,
    deleteProperty
};
