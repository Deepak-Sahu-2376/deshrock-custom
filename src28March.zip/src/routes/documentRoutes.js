import express from 'express';
import multer from 'multer';
import { protect } from '../middlewares/authMiddleware.js';
import db from '../models/index.js';
const { pool } = db;

const storage = multer.diskStorage({
    destination(req, file, cb) { cb(null, 'uploads/') },
    filename(req, file, cb) { cb(null, `doc-${Date.now()}-${file.originalname}`) }
});
const upload = multer({ storage });

const router = express.Router();

router.post('/upload', protect, upload.single('file'), async (req, res) => {
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded' });

    try {
        const { documentType } = req.body;
        const userId = req.user.id;

        let entityType = 'USER';
        // Normalize userType to entityType ENUM
        if (req.user.userType && req.user.userType.toLowerCase().includes('agent')) {
            entityType = 'AGENT';
        } else if (req.user.userType && req.user.userType.toLowerCase().includes('company')) {
            entityType = 'COMPANY';
        }

        const insertQuery = `
            INSERT INTO "Documents" ("entityId", "entityType", "documentType", "fileName", "fileUrl", "mimeType", "fileSize", status, "createdAt", "updatedAt")
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW(), NOW())
            RETURNING *;
        `;
        const values = [
            userId,
            entityType,
            documentType || 'registration_document',
            req.file.originalname,
            `/uploads/${req.file.filename}`,
            req.file.mimetype,
            req.file.size,
            'PENDING'
        ];

        const result = await pool.query(insertQuery, values);
        const newDoc = result.rows[0];

        res.json({
            success: true,
            message: 'File uploaded and saved successfully',
            data: newDoc
        });
    } catch (error) {
        console.error('Upload error:', error);
        res.status(500).json({ success: false, message: 'Failed to save document record' });
    }
});


// GET /api/v1/documents/entity/:entityType/:entityId
router.get('/entity/:entityType/:entityId', protect, async (req, res) => {
    const { entityType, entityId } = req.params;

    try {
        let userId = entityId;

        if (entityType === 'AGENT') {
            const agentRes = await pool.query('SELECT "userId" FROM "AgentProfiles" WHERE id = $1', [entityId]);
            if (agentRes.rows.length > 0) userId = agentRes.rows[0].userId;
        } else if (entityType === 'COMPANY') {
            const companyRes = await pool.query('SELECT "userId" FROM "CompanyProfiles" WHERE id = $1', [entityId]);
            if (companyRes.rows.length > 0) userId = companyRes.rows[0].userId;
        }

        const docsRes = await pool.query(`
            SELECT * FROM "Documents"
            WHERE "entityId" = $1 AND "entityType" = $2
            ORDER BY "createdAt" DESC
        `, [userId, entityType]);

        res.json({
            success: true,
            data: {
                content: docsRes.rows
            }
        });
    } catch (error) {
        console.error('Error fetching docs:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch documents' });
    }
});

export default router;
