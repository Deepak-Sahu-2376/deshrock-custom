import express from 'express';
const router = express.Router();
import { uploadShort, getAllShorts, getPropertyShorts, deleteShort, incrementView } from '../controllers/shortController.js';
import { protect, authorize } from '../middlewares/authMiddleware.js';
import upload from '../middlewares/uploadMiddleware.js';

// Public routes
router.get('/', getAllShorts);
router.get('/property/:propertyId', getPropertyShorts);
router.patch('/:id/view', incrementView);

// Private routes
router.post('/upload/:propertyId', protect, upload.single('video'), uploadShort);
router.delete('/:id', protect, deleteShort);

export default router;
