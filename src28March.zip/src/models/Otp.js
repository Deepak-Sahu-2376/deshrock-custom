import pool from '../config/database.js';

class OtpRepository {
    async create(otpData) {
        const { identifier, code, expiresAt, purpose = 'registration' } = otpData;
        const query = `
            INSERT INTO "Otps" (identifier, code, "expiresAt", purpose, "createdAt", "updatedAt")
            VALUES ($1, $2, $3, $4, NOW(), NOW())
            RETURNING *;
        `;
        const values = [identifier, code, expiresAt, purpose];
        const result = await pool.query(query, values);
        return result.rows[0];
    }

    async findByIdentifierAndCode(identifier, code, purpose = 'registration') {
        const query = `
            SELECT * FROM "Otps"
            WHERE identifier = $1 AND code = $2 AND purpose = $3
            ORDER BY "createdAt" DESC
            LIMIT 1;
        `;
        const result = await pool.query(query, [identifier, code, purpose]);
        return result.rows[0];
    }

    async markAsUsed(id) {
        const query = `
            UPDATE "Otps"
            SET "isUsed" = true, "updatedAt" = NOW()
            WHERE id = $1
            RETURNING *;
        `;
        const result = await pool.query(query, [id]);
        return result.rows[0];
    }
}

export default new OtpRepository();
