import pool from '../config/database.js';

class CompanyProfileRepository {
    async create(profileData) {
        const {
            userId, companyName, companyType, registrationNumber,
            establishmentYear, contactPersonName, contactPersonDesignation,
            alternateEmail, address, city, state, country, pincode,
            description, serviceAreas, specializations, gstNumber,
            panNumber, licenseNumber, licenseAuthority, licenseExpiryDate,
            website, employeeCount, status
        } = profileData;

        const query = `
            INSERT INTO "CompanyProfiles" (
                "userId", "companyName", "companyType", "registrationNumber",
                "establishmentYear", "contactPersonName", "contactPersonDesignation",
                "alternateEmail", "address", "city", "state", "country", "pincode",
                "description", "serviceAreas", "specializations", "gstNumber",
                "panNumber", "licenseNumber", "licenseAuthority", "licenseExpiryDate",
                "website", "employeeCount", "status", "updatedAt"
            ) VALUES (
                $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14,
                $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, NOW()
            ) RETURNING *;
        `;
        const values = [
            userId, companyName, companyType || null, registrationNumber || null,
            establishmentYear || null, contactPersonName || null, contactPersonDesignation || null,
            alternateEmail || null, address || null, city || null, state || null, country || null, pincode || null,
            description || null, serviceAreas || [], specializations || [], gstNumber || null,
            panNumber || null, licenseNumber || null, licenseAuthority || null, licenseExpiryDate || null,
            website || null, employeeCount || 0, status || 'pending'
        ];

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    async findByUserId(userId) {
        const result = await pool.query('SELECT * FROM "CompanyProfiles" WHERE "userId" = $1', [userId]);
        return result.rows[0];
    }

    async findById(id) {
        const result = await pool.query('SELECT * FROM "CompanyProfiles" WHERE id = $1', [id]);
        return result.rows[0];
    }
}

export default new CompanyProfileRepository();
