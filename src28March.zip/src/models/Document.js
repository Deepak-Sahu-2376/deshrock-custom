import pool from '../config/database.js';

class DocumentRepository {
    async create(docData) {
        const { entityId, entityType, documentType, fileName, fileUrl, mimeType, fileSize, status } = docData;

        const query = `
            INSERT INTO "Documents" (
                "entityId", "entityType", "documentType", "fileName",
                "fileUrl", "mimeType", "fileSize", status, "updatedAt"
            ) VALUES (
                $1, $2, $3, $4, $5, $6, $7, $8, NOW()
            ) RETURNING *;
        `;
        const values = [
            entityId, entityType, documentType || null, fileName,
            fileUrl, mimeType || null, fileSize || null, status || 'PENDING'
        ];

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    async findByEntity(entityId, entityType) {
        const result = await pool.query(
            'SELECT * FROM "Documents" WHERE "entityId" = $1 AND "entityType" = $2 ORDER BY "createdAt" DESC',
            [entityId, entityType]
        );
        return result.rows;
    }
}

export default new DocumentRepository();
