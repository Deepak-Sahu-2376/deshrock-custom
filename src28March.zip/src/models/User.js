import bcrypt from 'bcryptjs';
import pool from '../config/database.js';

class UserRepository {
    async findById(id) {
        const result = await pool.query('SELECT * FROM "Users" WHERE id = $1', [id]);
        return result.rows[0];
    }

    async findByEmail(email) {
        const result = await pool.query('SELECT * FROM "Users" WHERE email = $1', [email]);
        return result.rows[0];
    }

    async findByIdentifier(identifier) {
        const result = await pool.query('SELECT * FROM "Users" WHERE identifier = $1', [identifier]);
        return result.rows[0];
    }

    async create(userData) {
        let {
            email, identifier, password, firstName, lastName, phone, userType,
            isVerified, avatar, acceptTerms, acceptPrivacyPolicy,
            allowMarketingEmails, allowSmsNotifications, profileComplete
        } = userData;

        if (password) {
            const salt = await bcrypt.genSalt(10);
            password = await bcrypt.hash(password, salt);
        }

        const query = `
            INSERT INTO "Users" (
                email, identifier, password, "firstName", "lastName", phone, "userType",
                "isVerified", avatar, "acceptTerms", "acceptPrivacyPolicy",
                "allowMarketingEmails", "allowSmsNotifications", "profileComplete",
                "updatedAt"
            ) VALUES (
                $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, NOW()
            ) RETURNING *;
        `;
        const values = [
            email,
            identifier, // fallback handled in controller
            password,
            firstName,
            lastName,
            phone || null,
            userType || 'buyer',
            isVerified || false,
            avatar || null,
            acceptTerms || false,
            acceptPrivacyPolicy || false,
            allowMarketingEmails || false,
            allowSmsNotifications || false,
            profileComplete || false
        ];

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    async update(id, updateData) {
        if (updateData.password) {
            const salt = await bcrypt.genSalt(10);
            updateData.password = await bcrypt.hash(updateData.password, salt);
        }

        updateData.updatedAt = new Date();

        const setClause = [];
        const values = [];
        let i = 1;

        for (const [key, value] of Object.entries(updateData)) {
            setClause.push(`"${key}" = $${i}`);
            values.push(value);
            i++;
        }

        if (setClause.length === 0) return await this.findById(id);

        values.push(id);
        const query = `
            UPDATE "Users"
            SET ${setClause.join(', ')}
            WHERE id = $${i}
            RETURNING *;
        `;

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    async matchPassword(enteredPassword, userPassword) {
        return await bcrypt.compare(enteredPassword, userPassword);
    }
}

export default new UserRepository();
