import pool from '../config/database.js';

class VisitRepository {
    async create(visitData) {
        const { userId, propertyId, agentId, preferredVisitTime, status, message, adminNotes } = visitData;

        const query = `
            INSERT INTO "Visits" (
                "userId", "propertyId", "agentId", "preferredVisitTime",
                status, message, "adminNotes", "updatedAt"
            ) VALUES (
                $1, $2, $3, $4, $5, $6, $7, NOW()
            ) RETURNING *;
        `;
        const values = [
            userId, propertyId, agentId || null, preferredVisitTime,
            status || 'PENDING', message || null, adminNotes || null
        ];

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    async findById(id) {
        const result = await pool.query('SELECT * FROM "Visits" WHERE id = $1', [id]);
        return result.rows[0];
    }
}

export default new VisitRepository();
