import pool from '../config/database.js';

class PhaseRepository {
    async create(phaseData) {
        const {
            projectId, name, phaseNumber, status, constructionStatus,
            reraNumber, description, totalUnits, bookedUnits, soldUnits,
            availableUnits, startingPrice, completionPercentage, approvedAt,
            phaseLogoUrl, phaseBrochureUrl, masterPlanUrl, floorPlanUrls,
            specifications
        } = phaseData;

        const query = `
            INSERT INTO "Phases" (
                "projectId", name, "phaseNumber", status, "constructionStatus",
                "reraNumber", description, "totalUnits", "bookedUnits", "soldUnits",
                "availableUnits", "startingPrice", "completionPercentage", "approvedAt",
                "phaseLogoUrl", "phaseBrochureUrl", "masterPlanUrl", "floorPlanUrls",
                specifications, "updatedAt"
            ) VALUES (
                $1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
                $11, $12, $13, $14, $15, $16, $17, $18, $19, NOW()
            ) RETURNING *;
        `;
        const values = [
            projectId, name, phaseNumber || null, status || 'PLANNING',
            constructionStatus || null, reraNumber || null, description || null,
            totalUnits || 0, bookedUnits || 0, soldUnits || 0, availableUnits || 0,
            startingPrice || null, completionPercentage || 0, approvedAt || null,
            phaseLogoUrl || null, phaseBrochureUrl || null, masterPlanUrl || null,
            JSON.stringify(floorPlanUrls || []), specifications || null
        ];

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    async findByProjectId(projectId) {
        const result = await pool.query('SELECT * FROM "Phases" WHERE "projectId" = $1 ORDER BY "phaseNumber" ASC', [projectId]);
        return result.rows;
    }
}

export default new PhaseRepository();
