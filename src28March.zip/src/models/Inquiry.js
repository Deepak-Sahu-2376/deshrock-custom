import pool from '../config/database.js';

class InquiryRepository {
    async create(inquiryData) {
        const { propertyId, projectId, userId, name, email, phone, message, status } = inquiryData;

        const query = `
            INSERT INTO "Inquiries" (
                "propertyId", "projectId", "userId", name,
                email, phone, message, status, "updatedAt"
            ) VALUES (
                $1, $2, $3, $4, $5, $6, $7, $8, NOW()
            ) RETURNING *;
        `;
        const values = [
            propertyId || null, projectId || null, userId || null, name,
            email, phone, message, status || 'PENDING'
        ];

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    async findById(id) {
        const result = await pool.query('SELECT * FROM "Inquiries" WHERE id = $1', [id]);
        return result.rows[0];
    }
}

export default new InquiryRepository();
