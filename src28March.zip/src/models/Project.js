import pool from '../config/database.js';

class ProjectRepository {
    async create(projectData) {
        const {
            companyId, name, description, projectType, status,
            approvalStatus, isActive, isFeatured, developerName, architectName,
            totalPhases, totalTowers, totalFloors, totalUnits, availableUnits, totalArea,
            startingPrice, priceRangeMax, avgPrice, pricePerSqft,
            launchDate, possessionDate, expectedCompletion, address, city, state,
            pincode, country, latitude, longitude, locationAdvantages,
            reraApproved, reraNumber, reraValidityDate, amenities, media
        } = projectData;

        const query = `
            INSERT INTO "Projects" (
                "companyId", name, description, "projectType", status,
                "approvalStatus", "isActive", "isFeatured", "developerName", "architectName",
                "totalPhases", "totalTowers", "totalFloors", "totalUnits", "availableUnits", "totalArea",
                "startingPrice", "priceRangeMax", "avgPrice", "pricePerSqft",
                "launchDate", "possessionDate", "expectedCompletion", address, city, state,
                pincode, country, latitude, longitude, "locationAdvantages",
                "reraApproved", "reraNumber", "reraValidityDate", amenities, media, "updatedAt"
            ) VALUES (
                $1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
                $11, $12, $13, $14, $15, $16, $17, $18, $19, $20,
                $21, $22, $23, $24, $25, $26, $27, $28, $29, $30,
                $31, $32, $33, $34, $35, $36, NOW()
            ) RETURNING *;
        `;
        const values = [
            companyId, name, description || null, projectType, status || 'UNDER_CONSTRUCTION',
            approvalStatus || 'PENDING', isActive !== undefined ? isActive : true, isFeatured || false, developerName || null, architectName || null,
            totalPhases || 1, totalTowers || 0, totalFloors || 0, totalUnits || 0, availableUnits || 0, totalArea || null,
            startingPrice || null, priceRangeMax || null, avgPrice || null, pricePerSqft || null,
            launchDate || null, possessionDate || null, expectedCompletion || null, address || null, city || null, state || null,
            pincode || null, country || 'India', latitude || null, longitude || null, locationAdvantages || [],
            reraApproved || false, reraNumber || null, reraValidityDate || null, amenities || [], JSON.stringify(media || []),
        ];

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    async findById(id) {
        const result = await pool.query('SELECT * FROM "Projects" WHERE id = $1', [id]);
        return result.rows[0];
    }

    async findAll() {
        const result = await pool.query('SELECT * FROM "Projects" ORDER BY "createdAt" DESC');
        return result.rows;
    }
}

export default new ProjectRepository();
