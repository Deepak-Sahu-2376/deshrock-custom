import pool from '../config/database.js';

class PropertyRepository {
    async create(propertyData) {
        const {
            companyId, userId, title, description, propertyType, listingType,
            status, rejectionReason, bedrooms, bathrooms, balconies, furnishingStatus,
            pantry, washroom, carpetArea, builtUpArea, superBuiltUpArea, floorNumber,
            totalFloors, unitNumber, tower, isCornerUnit, basePrice, monthlyRent,
            securityDeposit, maintenanceCharges, floorRiseCharges, coveredParkingSpots,
            openParkingSpots, address, city, state, pincode, country, latitude, longitude,
            amenities, images, video, floorPlan, isFeatured, viewCount
        } = propertyData;

        const query = `
            INSERT INTO "Properties" (
                "companyId", "userId", title, description, "propertyType", "listingType",
                status, "rejectionReason", bedrooms, bathrooms, balconies, "furnishingStatus",
                pantry, washroom, "carpetArea", "builtUpArea", "superBuiltUpArea", "floorNumber",
                "totalFloors", "unitNumber", tower, "isCornerUnit", "basePrice", "monthlyRent",
                "securityDeposit", "maintenanceCharges", "floorRiseCharges", "coveredParkingSpots",
                "openParkingSpots", address, city, state, pincode, country, latitude, longitude,
                amenities, images, video, "floorPlan", "isFeatured", "viewCount", "updatedAt"
            ) VALUES (
                $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14,
                $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26,
                $27, $28, $29, $30, $31, $32, $33, $34, $35, $36, $37, $38,
                $39, $40, $41, $42, NOW()
            ) RETURNING *;
        `;
        const values = [
            companyId || null, userId || null, title, description, propertyType, listingType,
            status || 'PENDING', rejectionReason || null, bedrooms || null, bathrooms || null, balconies || null, furnishingStatus || 'UNFURNISHED',
            pantry || false, washroom || false, carpetArea, builtUpArea || null, superBuiltUpArea || null, floorNumber || null,
            totalFloors || null, unitNumber || null, tower || null, isCornerUnit || false, basePrice || null, monthlyRent || null,
            securityDeposit || null, maintenanceCharges || null, floorRiseCharges || 0, coveredParkingSpots || 0,
            openParkingSpots || 0, address, city, state, pincode, country || 'India', latitude || null, longitude || null,
            amenities || [], images || [], video || null, floorPlan || null, isFeatured || false, viewCount || 0
        ];

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    async findById(id) {
        const result = await pool.query('SELECT * FROM "Properties" WHERE id = $1', [id]);
        return result.rows[0];
    }

    async findAll() {
        const result = await pool.query('SELECT * FROM "Properties" ORDER BY "createdAt" DESC');
        return result.rows;
    }
}

export default new PropertyRepository();
