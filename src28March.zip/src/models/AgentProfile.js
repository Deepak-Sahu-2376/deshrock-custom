import pool from '../config/database.js';

class AgentProfileRepository {
    async create(profileData) {
        const {
            userId, city, state, country, address, pincode,
            specialization, experienceYears, bio, serviceAreas, languages,
            dob, agentType, companyId, companyName, profileVisibility, status
        } = profileData;

        const query = `
            INSERT INTO "AgentProfiles" (
                "userId", city, state, country, address, pincode,
                specialization, "experienceYears", bio, "serviceAreas", languages,
                dob, "agentType", "companyId", "companyName", "profileVisibility",
                status, "updatedAt"
            ) VALUES (
                $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13,
                $14, $15, $16, $17, NOW()
            ) RETURNING *;
        `;
        const values = [
            userId, city || null, state || null, country || null, address || null, pincode || null,
            specialization || null, experienceYears || 0, bio || null, serviceAreas || [], languages || [],
            dob || null, agentType || 'INDIVIDUAL', companyId || null, companyName || null,
            profileVisibility !== undefined ? profileVisibility : true, status || 'pending'
        ];

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    async findByUserId(userId) {
        const result = await pool.query('SELECT * FROM "AgentProfiles" WHERE "userId" = $1', [userId]);
        return result.rows[0];
    }

    async findById(id) {
        const result = await pool.query('SELECT * FROM "AgentProfiles" WHERE id = $1', [id]);
        return result.rows[0];
    }
}

export default new AgentProfileRepository();
