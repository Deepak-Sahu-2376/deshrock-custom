import db from '../models/index.js';
const { pool, User: UserRepository, Otp: OtpRepository, CompanyProfile: CompanyProfileRepository, AgentProfile: AgentProfileRepository } = db;
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { validationResult } from 'express-validator';
import { sendTemplateEmail } from '../services/emailService.js';

const generateToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET, {
        expiresIn: '30d'
    });
};

const matchPassword = async (enteredPassword, storedPasswordHash) => {
    return await bcrypt.compare(enteredPassword, storedPasswordHash);
};

// @desc    Auth user & get token (Login)
// @route   POST /api/v1/auth/login
const loginUser = async (req, res) => {
    const { identifier, password } = req.body;

    try {
        const userRes = await pool.query('SELECT * FROM "Users" WHERE identifier ILIKE $1 OR email ILIKE $1', [identifier]);
        const user = userRes.rows[0];

        if (user && (await matchPassword(password, user.password))) {
            // Map userType to frontend expectations
            let mappedUserType = user.userType;
            const type = user.userType.toLowerCase();

            if (type === 'company') mappedUserType = 'COMPANY_ADMIN';
            else if (type === 'admin') mappedUserType = 'ADMIN';
            else if (type === 'agent') mappedUserType = 'AGENT';
            else if (type === 'buyer') mappedUserType = 'BUYER';
            else mappedUserType = user.userType.toUpperCase();

            // Fetch Company ID if applicable
            let companyId = null;
            if (type === 'company') {
                const companyProfileRes = await pool.query('SELECT id FROM "CompanyProfiles" WHERE "userId" = $1', [user.id]);
                if (companyProfileRes.rows.length > 0) companyId = companyProfileRes.rows[0].id;
            }

            // [NEW] Send New Login Email
            const loginData = {
                userName: user.firstName,
                dateTime: new Date().toLocaleString(),
                device: req.headers['user-agent'] || 'Unknown Device',
                location: 'Unknown Location',
                reportLink: `${process.env.CLIENT_URL}/support`
            };
            sendTemplateEmail(user.email, 'NEW_LOGIN', loginData).catch(console.error);

            res.json({
                success: true,
                data: {
                    accessToken: generateToken(user.id),
                    user: {
                        id: user.id,
                        firstName: user.firstName,
                        lastName: user.lastName,
                        email: user.email,
                        userType: mappedUserType,
                        avatar: user.avatar,
                        companyId: companyId
                    }
                }
            });
        } else {
            res.status(401).json({ success: false, message: 'Invalid identifier or password' });
        }
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Register Buyer
// @route   POST /api/v1/auth/register
const registerBuyer = async (req, res) => {
    const { firstName, lastName, email, phone, password, userType, confirmPassword } = req.body;

    // Check pass match
    if (password !== confirmPassword) {
        return res.status(400).json({ success: false, message: 'Passwords do not match' });
    }

    try {
        const userRes = await pool.query('SELECT * FROM "Users" WHERE email ILIKE $1', [email]);
        let user = userRes.rows[0];

        if (user && user.isVerified) {
            return res.status(400).json({ success: false, message: 'User already exists' });
        }

        const lowerCaseUserType = (userType || 'buyer').toLowerCase();
        const hashedPassword = await bcrypt.hash(password, 10);

        if (user && !user.isVerified) {
            // User exists but not verified. Update passwords/info and resend OTP.
            const updateQuery = `
                UPDATE "Users" 
                SET "firstName" = $1, "lastName" = $2, phone = $3, password = $4, "userType" = $5,
                    "acceptTerms" = $6, "acceptPrivacyPolicy" = $7, "allowMarketingEmails" = $8, "allowSmsNotifications" = $9, "profileComplete" = $10,
                    "updatedAt" = NOW()
                WHERE id = $11 RETURNING *
            `;
            const updatedUserRes = await pool.query(updateQuery, [
                firstName, lastName, phone, hashedPassword, lowerCaseUserType,
                req.body.acceptTerms, req.body.acceptPrivacyPolicy, req.body.allowMarketingEmails, req.body.allowSmsNotifications, req.body.profileComplete,
                user.id
            ]);
            user = updatedUserRes.rows[0];
        } else {
            // Create New Unverified User
            const insertQuery = `
                INSERT INTO "Users" 
                (identifier, email, "firstName", "lastName", phone, password, "userType", "isVerified", 
                 "acceptTerms", "acceptPrivacyPolicy", "allowMarketingEmails", "allowSmsNotifications", "profileComplete", "createdAt", "updatedAt")
                VALUES ($1, $2, $3, $4, $5, $6, $7, false, $8, $9, $10, $11, $12, NOW(), NOW()) RETURNING *
            `;
            const insertedUserRes = await pool.query(insertQuery, [
                email, email, firstName, lastName, phone, hashedPassword, lowerCaseUserType,
                req.body.acceptTerms, req.body.acceptPrivacyPolicy, req.body.allowMarketingEmails, req.body.allowSmsNotifications, req.body.profileComplete
            ]);
            user = insertedUserRes.rows[0];

            // Auto-create Profile based on userType (Only for new users)
            if (lowerCaseUserType === 'company') {
                const insertCompanyQuery = `
                    INSERT INTO "CompanyProfiles" ("userId", "companyName", "contactPersonName", status, "createdAt", "updatedAt")
                    VALUES ($1, $2, $3, 'pending', NOW(), NOW())
                `;
                await pool.query(insertCompanyQuery, [user.id, `${firstName} ${lastName}'s Company`, `${firstName} ${lastName}`]);
            } else if (lowerCaseUserType === 'agent') {
                const insertAgentQuery = `
                    INSERT INTO "AgentProfiles" ("userId", status, "agentType", "createdAt", "updatedAt")
                    VALUES ($1, 'pending', 'INDIVIDUAL', NOW(), NOW())
                `;
                await pool.query(insertAgentQuery, [user.id]);
            }
        }

        // Generate OTP
        const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
        const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 mins

        // Invalidate old OTPs for this purpose
        await pool.query(`UPDATE "Otps" SET "isUsed" = true, "updatedAt" = NOW() WHERE identifier = $1 AND purpose = 'registration' AND "isUsed" = false`, [email]);

        await OtpRepository.create({
            identifier: email,
            code: otpCode,
            expiresAt,
            purpose: 'registration'
        });

        // Send Email
        const otpData = {
            userName: firstName,
            otp: otpCode
        };
        await sendTemplateEmail(email, 'OTP_LOGIN', otpData);

        res.status(201).json({ success: true, message: 'User registered. Please verify OTP.' });

    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Verify Registration OTP
// @route   POST /api/v1/auth/verify-registration
const verifyBuyerRegistration = async (req, res) => {
    const { email, otpCode } = req.body;
    try {
        const otpRes = await pool.query(`
            SELECT * FROM "Otps" 
            WHERE identifier ILIKE $1 AND code = $2 AND "isUsed" = false AND purpose = 'registration' AND "expiresAt" > NOW()
        `, [email, otpCode]);
        const otp = otpRes.rows[0];

        if (!otp) return res.status(400).json({ success: false, message: 'Invalid or expired OTP' });

        const userRes = await pool.query('SELECT * FROM "Users" WHERE email ILIKE $1', [email]);
        const user = userRes.rows[0];

        if (!user) return res.status(404).json({ success: false, message: 'User not found' });

        // Logic Change: Only BUYER gets auto-verified. Others need Admin API.
        if (user.userType === 'buyer') {
            await pool.query(`UPDATE "Users" SET "isVerified" = true, "updatedAt" = NOW() WHERE id = $1`, [user.id]);
        }

        await pool.query(`UPDATE "Otps" SET "isUsed" = true, "updatedAt" = NOW() WHERE id = $1`, [otp.id]);

        res.json({ success: true, message: 'Registration verified.' });

    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Logout
// @route   POST /api/v1/auth/logout
const logoutUser = (req, res) => {
    res.json({ success: true, message: 'Logged out successfully' });
};

// @desc    Forgot Password (Send OTP)
// @route   POST /api/v1/auth/forgot-password
const forgotPassword = async (req, res) => {
    const { identifier } = req.body;
    const email = identifier || req.query.identifier;

    try {
        const userRes = await pool.query('SELECT * FROM "Users" WHERE email ILIKE $1', [email]);
        const user = userRes.rows[0];

        if (!user) return res.status(404).json({ success: false, message: 'User not found' });

        const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
        const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

        await OtpRepository.create({
            identifier: email,
            code: otpCode,
            expiresAt,
            purpose: 'reset_password'
        });

        const otpData = {
            userName: user.firstName,
            otp: otpCode
        };
        const emailSent = await sendTemplateEmail(email, 'FORGOT_PASSWORD', otpData);

        if (!emailSent) {
            return res.status(500).json({ success: false, message: 'Failed to send OTP email. Please try again later.' });
        }

        res.json({ success: true, message: 'OTP sent for password reset.' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Reset Password
// @route   POST /api/v1/auth/reset-password
const resetPassword = async (req, res) => {
    const { identifier, otpCode, newPassword, confirmPassword } = req.body;

    if (newPassword !== confirmPassword) return res.status(400).json({ success: false, message: 'Passwords do not match' });

    try {
        const otpRes = await pool.query(`
            SELECT * FROM "Otps" 
            WHERE identifier ILIKE $1 AND code = $2 AND "isUsed" = false AND purpose = 'reset_password' AND "expiresAt" > NOW()
        `, [identifier, otpCode]);
        const otp = otpRes.rows[0];

        if (!otp) return res.status(400).json({ success: false, message: 'Invalid or expired OTP' });

        const userRes = await pool.query('SELECT * FROM "Users" WHERE identifier ILIKE $1 OR email ILIKE $1', [identifier]);
        const user = userRes.rows[0];

        if (!user) return res.status(404).json({ success: false, message: 'User not found' });

        const hashedPassword = await bcrypt.hash(newPassword, 10);
        await pool.query(`UPDATE "Users" SET password = $1, "updatedAt" = NOW() WHERE id = $2`, [hashedPassword, user.id]);

        await pool.query(`UPDATE "Otps" SET "isUsed" = true, "updatedAt" = NOW() WHERE id = $1`, [otp.id]);

        const pwdData = {
            userName: user.firstName,
            dateTime: new Date().toLocaleString(),
            device: req.headers['user-agent'] || 'Unknown Device',
            location: 'Unknown Location',
            resetLink: `${process.env.CLIENT_URL}/forgot-password`,
            reportLink: `${process.env.CLIENT_URL}/support`
        };
        sendTemplateEmail(user.email, 'PASSWORD_CHANGED', pwdData).catch(console.error);

        res.json({ success: true, message: 'Password reset successfully.' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

export {
    loginUser,
    registerBuyer,
    verifyBuyerRegistration,
    logoutUser,
    forgotPassword,
    resetPassword
};
