import db from '../models/index.js';
const { pool, CompanyProfile: CompanyProfileRepository, AgentProfile: AgentProfileRepository, User: UserRepository } = db;
import { sendTemplateEmail } from '../services/emailService.js';

// Helper for Pagination
const getPaginationOptions = (page, size) => {
    const limit = size ? +size : 10;
    const offset = page ? page * limit : 0;
    return { limit, offset };
};

// @desc    Get pending company requests
// @route   GET /api/v1/admin/dashboard/pending-approvals/companies
const getPendingCompanies = async (req, res) => {
    try {
        const { limit, offset } = getPaginationOptions(req.query.page, req.query.size);

        const countResult = await pool.query(`SELECT COUNT(*) FROM "CompanyProfiles" WHERE status = 'pending'`);
        const totalElements = parseInt(countResult.rows[0].count, 10);

        const rowsQuery = `
            SELECT c.*, 
                   json_build_object('firstName', u."firstName", 'lastName', u."lastName", 'email', u.email, 'phone', u.phone) as user
            FROM "CompanyProfiles" c
            LEFT JOIN "Users" u ON c."userId" = u.id
            WHERE c.status = 'pending'
            ORDER BY c."createdAt" ASC
            LIMIT $1 OFFSET $2
        `;
        const { rows } = await pool.query(rowsQuery, [limit, offset]);

        res.status(200).json({
            success: true,
            content: rows,
            data: {
                content: rows,
                totalPages: Math.ceil(totalElements / limit),
                totalElements
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get pending individual agents
// @route   GET /api/v1/admin/agents/pending-approval/individual
const getPendingAgents = async (req, res) => {
    try {
        const { limit, offset } = getPaginationOptions(req.query.page, req.query.size);

        const countResult = await pool.query(`SELECT COUNT(*) FROM "AgentProfiles" WHERE status = 'pending' AND "agentType" = 'INDIVIDUAL'`);
        const totalElements = parseInt(countResult.rows[0].count, 10);

        const rowsQuery = `
            SELECT a.*, 
                   json_build_object('firstName', u."firstName", 'lastName', u."lastName", 'email', u.email, 'phone', u.phone) as user
            FROM "AgentProfiles" a
            LEFT JOIN "Users" u ON a."userId" = u.id
            WHERE a.status = 'pending' AND a."agentType" = 'INDIVIDUAL'
            ORDER BY a."createdAt" ASC
            LIMIT $1 OFFSET $2
        `;
        const { rows } = await pool.query(rowsQuery, [limit, offset]);

        // Flatten the structure for the frontend
        const flatRows = rows.map(row => {
            return {
                ...row,
                firstName: row.user?.firstName,
                lastName: row.user?.lastName,
                email: row.user?.email,
                phone: row.user?.phone
            };
        });

        res.status(200).json({
            success: true,
            content: flatRows,
            data: {
                content: flatRows,
                totalPages: Math.ceil(totalElements / limit),
                totalElements
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Approve Company
// @route   POST /api/v1/admin/companies/:id/approve
const approveCompany = async (req, res) => {
    const { id } = req.params;
    try {
        const company = await CompanyProfileRepository.findById(id);

        if (!company) {
            return res.status(404).json({ success: false, message: 'Company not found' });
        }

        await pool.query(`UPDATE "CompanyProfiles" SET status = 'approved', "updatedAt" = NOW() WHERE id = $1`, [id]);

        if (company.userId) {
            await pool.query(`UPDATE "Users" SET "isVerified" = true, "updatedAt" = NOW() WHERE id = $1`, [company.userId]);

            const userRes = await pool.query(`SELECT * FROM "Users" WHERE id = $1`, [company.userId]);
            const user = userRes.rows[0];

            if (user) {
                // Send Verification Email
                const emailData = {
                    userName: user.firstName,
                    companyName: company.companyName,
                    dashboardLink: `${process.env.CLIENT_URL}/dashboard`
                };
                sendTemplateEmail(user.email, 'COMPANY_VERIFIED', emailData).catch(console.error);
            }
        }

        res.status(200).json({ success: true, message: 'Company approved successfully' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Reject Company
// @route   POST /api/v1/admin/companies/:id/reject
const rejectCompany = async (req, res) => {
    const { id } = req.params;
    const { rejectionReason } = req.body;
    try {
        const company = await CompanyProfileRepository.findById(id);

        if (!company) {
            return res.status(404).json({ success: false, message: 'Company not found' });
        }

        await pool.query(`UPDATE "CompanyProfiles" SET status = 'rejected', "updatedAt" = NOW() WHERE id = $1`, [id]);

        if (company.userId) {
            const userRes = await pool.query('SELECT * FROM "Users" WHERE id = $1', [company.userId]);
            const user = userRes.rows[0];

            if (user) {
                // Send Rejection Email
                const rejectData = {
                    userName: user.firstName,
                    companyName: company.companyName,
                    reasons: [rejectionReason || 'Documents mismatch or incomplete information'],
                    uploadLink: `${process.env.CLIENT_URL}/company/verification`
                };
                sendTemplateEmail(user.email, 'COMPANY_REJECTED', rejectData).catch(console.error);
            }
        }

        res.status(200).json({ success: true, message: 'Company rejected' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Approve Agent
// @route   POST /api/v1/admin/agents/:id/approve
const approveAgent = async (req, res) => {
    const { id } = req.params;
    try {
        const agent = await AgentProfileRepository.findById(id);

        if (!agent) {
            return res.status(404).json({ success: false, message: 'Agent not found' });
        }

        await pool.query(`UPDATE "AgentProfiles" SET status = 'approved', "updatedAt" = NOW() WHERE id = $1`, [id]);

        if (agent.userId) {
            await pool.query(`UPDATE "Users" SET "isVerified" = true, "updatedAt" = NOW() WHERE id = $1`, [agent.userId]);
        }

        res.status(200).json({ success: true, message: 'Agent approved successfully' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Reject Agent
// @route   POST /api/v1/admin/agents/:id/reject
const rejectAgent = async (req, res) => {
    const { id } = req.params;
    try {
        const result = await pool.query(`UPDATE "AgentProfiles" SET status = 'rejected', "updatedAt" = NOW() WHERE id = $1 RETURNING id`, [id]);

        if (result.rowCount === 0) {
            return res.status(404).json({ success: false, message: 'Agent not found' });
        }

        res.status(200).json({ success: true, message: 'Agent rejected' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get pending company agents
// @route   GET /api/v1/admin/agents/pending-approval/from-company
const getPendingCompanyAgents = async (req, res) => {
    try {
        const { limit, offset } = getPaginationOptions(req.query.page, req.query.size);

        const countResult = await pool.query(`SELECT COUNT(*) FROM "AgentProfiles" WHERE status = 'pending' AND "agentType" = 'COMPANY_AGENT'`);
        const totalElements = parseInt(countResult.rows[0].count, 10);

        const rowsQuery = `
            SELECT a.*, 
                   json_build_object('firstName', u."firstName", 'lastName', u."lastName", 'email', u.email, 'phone', u.phone) as user,
                   json_build_object('companyName', c."companyName") as company
            FROM "AgentProfiles" a
            LEFT JOIN "Users" u ON a."userId" = u.id
            LEFT JOIN "CompanyProfiles" c ON a."companyId" = c.id
            WHERE a.status = 'pending' AND a."agentType" = 'COMPANY_AGENT'
            ORDER BY a."createdAt" ASC
            LIMIT $1 OFFSET $2
        `;
        const { rows } = await pool.query(rowsQuery, [limit, offset]);

        // Flatten the structure for the frontend
        const flatRows = rows.map(row => {
            return {
                ...row,
                firstName: row.user?.firstName,
                lastName: row.user?.lastName,
                email: row.user?.email,
                phone: row.user?.phone,
                companyName: row.company?.companyName
            };
        });

        res.status(200).json({
            success: true,
            content: flatRows,
            data: {
                content: flatRows, // Frontend expects "content" or "data"
                totalPages: Math.ceil(totalElements / limit),
                totalElements
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

export {
    getPendingCompanies,
    getPendingAgents,
    getPendingCompanyAgents,
    approveCompany,
    rejectCompany,
    approveAgent,
    rejectAgent
};
