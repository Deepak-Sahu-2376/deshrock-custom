import db from '../models/index.js';
const { Project: ProjectRepository, CompanyProfile: CompanyProfileRepository, Phase: PhaseRepository, Inquiry: InquiryRepository, pool } = db;
import { sendTemplateEmail } from '../services/emailService.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { uploadToYouTube } from '../services/youtubeService.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create a new project
export const createProject = async (req, res) => {
    try {
        console.log("Create Project Request Body:", req.body);
        console.log("Create Project Files:", req.files);

        // 1. Parse projectDTO
        let projectData;
        try {
            projectData = JSON.parse(req.body.projectDTO);
        } catch (e) {
            return res.status(400).json({ message: 'Invalid project data format' });
        }

        // 2. Validate Company
        const companyRes = await pool.query('SELECT id FROM "CompanyProfiles" WHERE id = $1', [projectData.companyId]);
        const company = companyRes.rows[0];

        if (!company) {
            return res.status(404).json({ message: 'Company not found' });
        }

        // 3. Process Files & Build Media Array
        const mediaArray = [];

        // Check if files exist
        if (req.files && req.files['mediaFiles']) {
            const files = req.files['mediaFiles'];
            const toArray = (val) => Array.isArray(val) ? val : [val];

            const mediaTypes = toArray(req.body.mediaTypes || []);
            const titles = toArray(req.body.titles || []);
            const categories = toArray(req.body.categories || []);
            const isPrimaryFlags = toArray(req.body.isPrimaryFlags || []);

            // Use for..of loop for async operations
            for (const [index, file] of files.entries()) {
                const type = mediaTypes[index] || 'OTHER';
                let fileUrl = `/uploads/documents/${file.filename}`;

                // Check for video and upload to YouTube
                if (file.mimetype.startsWith('video/')) {
                    try {
                        console.log(`Uploading project video ${file.originalname} to YouTube...`);
                        const videoId = await uploadToYouTube(
                            file.path,
                            titles[index] || file.originalname,
                            `Project Video: ${projectData.name}`
                        );
                        if (videoId) {
                            fileUrl = `https://www.youtube.com/watch?v=${videoId}`;
                            // Delete local file
                            fs.unlink(file.path, (err) => {
                                if (err) console.error('Error deleting local project video:', err);
                            });
                        }
                    } catch (ytError) {
                        console.error('YouTube upload failed for project video, keeping local:', ytError);
                    }
                }

                mediaArray.push({
                    type: type, // 'IMAGE', 'VIDEO'
                    url: fileUrl,
                    title: titles[index] || file.originalname,
                    category: categories[index] || 'OTHER',
                    isPrimary: isPrimaryFlags[index] === 'true'
                });
            }
        }

        // 3.1 Process URL-based Media (e.g., YouTube)
        if (req.body.mediaLinks) {
            try {
                const links = JSON.parse(req.body.mediaLinks);
                if (Array.isArray(links)) {
                    links.forEach(link => {
                        mediaArray.push({
                            type: link.type || 'VIDEO',
                            url: link.url,
                            title: link.title || 'Video',
                            category: link.category || 'VIDEO_TOUR',
                            isPrimary: link.isPrimary || false
                        });
                    });
                }
            } catch (e) {
                console.error("Error parsing mediaLinks:", e);
            }
        }

        // 4. Create Project Record
        const newProject = await ProjectRepository.create({
            ...projectData,
            companyId: projectData.companyId,
            media: mediaArray,
            status: 'UNDER_CONSTRUCTION' // Default
        });

        // Send Email
        const projectEmailData = {
            userName: req.user.firstName,
            projectName: newProject.name,
            location: newProject.city || 'Location',
            projectType: newProject.projectType || 'Residential',
            status: newProject.status,
            projectId: newProject.id,
            viewLink: `${process.env.CLIENT_URL}/projects/${newProject.id}`
        };
        sendTemplateEmail(req.user.email, 'PROJECT_ADDED', projectEmailData).catch(console.error);

        res.status(201).json({
            message: 'Project created successfully',
            project: newProject
        });

    } catch (error) {
        console.error('Error creating project:', error);
        res.status(500).json({ message: 'Server error while creating project', error: error.message });
    }
};

// Get Project by ID
export const getProjectById = async (req, res) => {
    try {
        const projectId = req.params.id;

        // Fetch project, company, and phases manually due to pg switch
        const project = await ProjectRepository.findById(projectId);

        if (!project) {
            return res.status(404).json({ message: 'Project not found' });
        }

        const companyRes = await pool.query('SELECT "companyName", id, website FROM "CompanyProfiles" WHERE id = $1', [project.companyId]);
        project.company = companyRes.rows[0];

        const phasesRes = await pool.query('SELECT * FROM "Phases" WHERE "projectId" = $1', [projectId]);
        project.phases = phasesRes.rows;

        // Transform media to match frontend expectations
        project.mediaFiles = (project.media || []).map(m => ({
            ...m,
            mediaUrl: m.url
        }));

        res.status(200).json({
            success: true,
            data: project
        });

    } catch (error) {
        console.error('Error fetching project:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};


// Update Project
export const updateProject = async (req, res) => {
    try {
        const projectId = req.params.id;
        let project = await ProjectRepository.findById(projectId);

        if (!project) {
            return res.status(404).json({ message: 'Project not found' });
        }

        // Auth: Admin or Company Owner
        let isAuthorized = false;
        if (req.user.userType === 'admin') {
            isAuthorized = true;
        } else {
            const companyRes = await pool.query('SELECT id FROM "CompanyProfiles" WHERE "userId" = $1', [req.user.id]);
            const company = companyRes.rows[0];

            if (company && company.id === project.companyId) {
                isAuthorized = true;
            }
        }

        if (!isAuthorized) {
            return res.status(403).json({ message: 'Not authorized to update this project' });
        }

        // Data
        let updates = req.body;
        if (req.body.projectDTO) {
            try {
                updates = JSON.parse(req.body.projectDTO);
            } catch (e) {
                return res.status(400).json({ message: 'Invalid project data' });
            }
        }

        // Update fields whitelist
        const allowedFields = ['name', 'description', 'city', 'address', 'projectType', 'launchDate', 'status', 'approvalStatus', 'amenities'];
        const sqlUpdates = [];
        const sqlValues = [];
        let paramIndex = 1;

        Object.keys(updates).forEach(key => {
            if (allowedFields.includes(key)) {
                sqlUpdates.push(`"${key}" = $${paramIndex}`);
                sqlValues.push(updates[key]);
                paramIndex++;
            }
        });

        // Admin override status
        if (req.user.userType === 'admin' && updates.approvalStatus) {
            if (!sqlUpdates.some(u => u.startsWith('"approvalStatus"'))) {
                sqlUpdates.push(`"approvalStatus" = $${paramIndex}`);
                sqlValues.push(updates.approvalStatus);
                paramIndex++;
            } else {
                const index = sqlUpdates.findIndex(u => u.startsWith('"approvalStatus"'));
                sqlValues[index] = updates.approvalStatus;
            }
        }

        // --- Media Handling ---
        let currentMedia = project.media || [];
        let mediaChanged = false;

        // 1. Handle Deletions
        if (req.body.mediaToDelete) {
            const toDelete = Array.isArray(req.body.mediaToDelete) ? req.body.mediaToDelete : [req.body.mediaToDelete];

            const newMedia = [];
            currentMedia.forEach(item => {
                if (toDelete.includes(item.url)) {
                    try {
                        const relativePath = item.url;
                        const safePath = relativePath.startsWith('/') ? relativePath.substring(1) : relativePath;
                        const absolutePath = path.join(process.cwd(), safePath);
                        if (fs.existsSync(absolutePath)) {
                            fs.unlinkSync(absolutePath);
                            console.log(`Deleted file: ${absolutePath}`);
                        }
                    } catch (e) {
                        console.error(`Failed to delete file ${item.url}:`, e);
                    }
                    mediaChanged = true;
                } else {
                    newMedia.push(item);
                }
            });
            currentMedia = newMedia;
        }

        // 2. Handle New Uploads
        if (req.files && req.files['mediaFiles']) {
            const files = req.files['mediaFiles'];
            const toArray = (val) => Array.isArray(val) ? val : [val];

            const mediaTypes = toArray(req.body.mediaTypes || []);
            const titles = toArray(req.body.titles || []);
            const categories = toArray(req.body.categories || []);
            const isPrimaryFlags = toArray(req.body.isPrimaryFlags || []);

            files.forEach((file, index) => {
                const type = mediaTypes[index] || 'OTHER';
                const fileUrl = `/uploads/documents/${file.filename}`;

                currentMedia.push({
                    type: type,
                    url: fileUrl,
                    title: titles[index] || file.originalname,
                    category: categories[index] || 'OTHER',
                    isPrimary: isPrimaryFlags[index] === 'true'
                });
            });
            mediaChanged = true;
        }

        // 3. Handle New URL-based Media
        if (req.body.mediaLinks) {
            try {
                const links = JSON.parse(req.body.mediaLinks);
                if (Array.isArray(links) && links.length > 0) {
                    links.forEach(link => {
                        currentMedia.push({
                            type: link.type || 'VIDEO',
                            url: link.url,
                            title: link.title || 'Video',
                            category: link.category || 'VIDEO_TOUR',
                            isPrimary: link.isPrimary || false
                        });
                    });
                    mediaChanged = true;
                }
            } catch (e) {
                console.error("Error parsing mediaLinks in update:", e);
            }
        }

        if (mediaChanged) {
            sqlUpdates.push(`"media" = $${paramIndex}`);
            sqlValues.push(JSON.stringify(currentMedia));
            paramIndex++;
        }

        let updatedProject = project;

        if (sqlUpdates.length > 0) {
            sqlUpdates.push(`"updatedAt" = NOW()`);
            sqlValues.push(projectId);
            const updateQuery = `UPDATE "Projects" SET ${sqlUpdates.join(', ')} WHERE id = $${paramIndex} RETURNING *`;
            const updated = await pool.query(updateQuery, sqlValues);
            updatedProject = updated.rows[0];
        }

        res.status(200).json({ message: 'Project updated successfully', project: updatedProject });

    } catch (error) {
        console.error('Error updating project:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

// Delete Project
export const deleteProject = async (req, res) => {
    try {
        const projectId = req.params.id;
        const project = await ProjectRepository.findById(projectId);
        if (!project) {
            return res.status(404).json({ message: 'Project not found' });
        }

        // Delete associated files
        if (project.media && Array.isArray(project.media)) {
            project.media.forEach(mediaItem => {
                if (mediaItem.url) {
                    try {
                        const relativePath = mediaItem.url;
                        const safePath = relativePath.startsWith('/') ? relativePath.substring(1) : relativePath;
                        const absolutePath = path.join(process.cwd(), safePath);

                        if (fs.existsSync(absolutePath)) {
                            fs.unlinkSync(absolutePath);
                            console.log(`Deleted file: ${absolutePath}`);
                        }
                    } catch (err) {
                        console.error(`Failed to delete file ${mediaItem.url}:`, err);
                    }
                }
            });
        }

        // Cascade delete related Inquiries (Visits are not linked to Projects)
        await pool.query('DELETE FROM "Inquiries" WHERE "projectId" = $1', [projectId]);

        // Delete the project
        await pool.query('DELETE FROM "Projects" WHERE id = $1', [projectId]);

        res.status(200).json({ message: 'Project deleted successfully' });

    } catch (error) {
        console.error('Error deleting project:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

export const getProjects = async (req, res) => {
    // Moved/Copied logic from propertyController if needed, 
    // or just export this and update routes. 
    // For now the existing getProjects is in propertyController.
    // I can stick to that or move it here later.
};
