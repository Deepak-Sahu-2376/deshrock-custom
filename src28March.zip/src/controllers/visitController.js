import db from '../models/index.js';
const { pool, Visit: VisitRepository, Property: PropertyRepository, User: UserRepository, CompanyProfile: CompanyProfileRepository } = db;

export const scheduleVisit = async (req, res, next) => {
    try {
        const { propertyId, preferredVisitTime, message } = req.body;
        const userId = req.user.id;

        if (!propertyId || !preferredVisitTime) {
            return res.status(400).json({ success: false, message: 'Property and Time are required' });
        }

        const property = await PropertyRepository.findById(propertyId);

        if (!property) {
            return res.status(404).json({ success: false, message: 'Property not found' });
        }

        let agentId = property.userId;

        if (!agentId && property.companyId) {
            const companyRes = await pool.query('SELECT "userId" FROM "CompanyProfiles" WHERE id = $1', [property.companyId]);
            if (companyRes.rows.length > 0) agentId = companyRes.rows[0].userId;
        }

        const visit = await VisitRepository.create({
            userId,
            propertyId,
            agentId,
            preferredVisitTime,
            message,
            status: 'PENDING'
        });

        res.status(201).json({ success: true, data: visit, message: 'Visit scheduled successfully' });
    } catch (error) {
        next(error);
    }
};

export const getMyVisits = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { page = 0, size = 10, sort = 'createdAt,desc' } = req.query;
        const limit = parseInt(size);
        const offset = parseInt(page) * limit;

        const [sortField, sortOrder] = sort.split(',');

        const countQuery = `SELECT COUNT(*) FROM "Visits" WHERE "userId" = $1`;
        const countRes = await pool.query(countQuery, [userId]);
        const count = parseInt(countRes.rows[0].count, 10);

        const rowsQuery = `
            SELECT v.*, 
                   json_build_object('id', p.id, 'title', p.title, 'address', p.address, 'images', p.images, 'basePrice', p."basePrice", 'monthlyRent', p."monthlyRent", 'listingType', p."listingType") as property,
                   json_build_object('id', u.id, 'firstName', u."firstName", 'lastName', u."lastName", 'email', u.email, 'phone', u.phone, 'userType', u."userType") as agent
            FROM "Visits" v
            LEFT JOIN "Properties" p ON v."propertyId" = p.id
            LEFT JOIN "Users" u ON v."agentId" = u.id
            WHERE v."userId" = $1
            ORDER BY v."${sortField || 'createdAt'}" ${sortOrder || 'DESC'}
            LIMIT $2 OFFSET $3
        `;
        const rowsRes = await pool.query(rowsQuery, [userId, limit, offset]);

        res.status(200).json({
            success: true,
            data: {
                content: rowsRes.rows,
                totalElements: count,
                totalPages: Math.ceil(count / limit),
                number: parseInt(page)
            }
        });
    } catch (error) {
        next(error);
    }
};

export const getAgentTodayVisits = async (req, res, next) => {
    try {
        const agentId = req.user.id;
        const startOfDay = new Date();
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date();
        endOfDay.setHours(23, 59, 59, 999);

        const { page = 0, size = 20 } = req.query;
        const limit = parseInt(size);
        const offset = parseInt(page) * limit;

        const countQuery = `
            SELECT COUNT(*) FROM "Visits" 
            WHERE "agentId" = $1 AND "preferredVisitTime" BETWEEN $2 AND $3
        `;
        const countRes = await pool.query(countQuery, [agentId, startOfDay, endOfDay]);
        const count = parseInt(countRes.rows[0].count, 10);

        const rowsQuery = `
            SELECT v.*, 
                   json_build_object('id', u.id, 'firstName', u."firstName", 'lastName', u."lastName", 'email', u.email, 'phone', u.phone) as user,
                   json_build_object('id', p.id, 'title', p.title, 'address', p.address) as property
            FROM "Visits" v
            LEFT JOIN "Users" u ON v."userId" = u.id
            LEFT JOIN "Properties" p ON v."propertyId" = p.id
            WHERE v."agentId" = $1 AND v."preferredVisitTime" BETWEEN $2 AND $3
            ORDER BY v."preferredVisitTime" ASC
            LIMIT $4 OFFSET $5
        `;
        const rowsRes = await pool.query(rowsQuery, [agentId, startOfDay, endOfDay, limit, offset]);

        const content = rowsRes.rows.map(v => ({
            ...v,
            fullName: v.user ? `${v.user.firstName} ${v.user.lastName}` : 'Unknown Buyer',
            propertyId: v.property ? v.property.id : 'Unknown'
        }));

        res.status(200).json({
            success: true,
            content: content,
            totalElements: count
        });
    } catch (error) {
        next(error);
    }
};

export const getAgentUpcomingVisits = async (req, res, next) => {
    try {
        const agentId = req.user.id;
        const now = new Date();

        const { page = 0, size = 20 } = req.query;
        const limit = parseInt(size);
        const offset = parseInt(page) * limit;

        const countQuery = `
            SELECT COUNT(*) FROM "Visits" 
            WHERE "agentId" = $1 AND "preferredVisitTime" > $2
        `;
        const countRes = await pool.query(countQuery, [agentId, now]);
        const count = parseInt(countRes.rows[0].count, 10);

        const rowsQuery = `
            SELECT v.*, 
                   json_build_object('id', u.id, 'firstName', u."firstName", 'lastName', u."lastName", 'email', u.email, 'phone', u.phone) as user,
                   json_build_object('id', p.id, 'title', p.title, 'address', p.address) as property
            FROM "Visits" v
            LEFT JOIN "Users" u ON v."userId" = u.id
            LEFT JOIN "Properties" p ON v."propertyId" = p.id
            WHERE v."agentId" = $1 AND v."preferredVisitTime" > $2
            ORDER BY v."preferredVisitTime" ASC
            LIMIT $3 OFFSET $4
        `;
        const rowsRes = await pool.query(rowsQuery, [agentId, now, limit, offset]);

        const content = rowsRes.rows.map(v => ({
            ...v,
            fullName: v.user ? `${v.user.firstName} ${v.user.lastName}` : 'Unknown Buyer',
            propertyId: v.property ? v.property.id : 'Unknown'
        }));

        res.status(200).json({
            success: true,
            content: content,
            totalElements: count
        });
    } catch (error) {
        next(error);
    }
};

export const updateVisitStatus = async (req, res, next) => {
    try {
        const { id } = req.params;
        const { status } = req.body;
        const agentId = req.user.id;

        const visit = await VisitRepository.findById(id);
        if (!visit) return res.status(404).json({ success: false, message: 'Visit not found' });

        if (visit.agentId !== agentId && req.user.userType !== 'admin') {
            return res.status(403).json({ success: false, message: 'Not authorized' });
        }

        const updateRes = await pool.query(`UPDATE "Visits" SET status = $1, "updatedAt" = NOW() WHERE id = $2 RETURNING *`, [status, id]);

        res.status(200).json({ success: true, message: 'Visit status updated', data: updateRes.rows[0] });
    } catch (error) {
        next(error);
    }
};

export const cancelVisitByUser = async (req, res, next) => {
    try {
        const { id } = req.params;
        const { reason } = req.body;
        const userId = req.user.id;

        const visit = await VisitRepository.findById(id);
        if (!visit) {
            return res.status(404).json({ success: false, message: 'Visit not found' });
        }

        if (visit.userId !== userId) {
            return res.status(403).json({ success: false, message: 'Not authorized to cancel this visit' });
        }

        if (['CANCELLED', 'REJECTED', 'COMPLETED'].includes(visit.status)) {
            return res.status(400).json({ success: false, message: `Visit is already ${visit.status}` });
        }

        let newAdminNotes = visit.adminNotes;
        if (reason) {
            const cancellationNote = `[Cancelled by User]: ${reason}`;
            newAdminNotes = newAdminNotes ? `${newAdminNotes}\n${cancellationNote}` : cancellationNote;
        }

        const updateRes = await pool.query(`UPDATE "Visits" SET status = 'CANCELLED', "adminNotes" = $1, "updatedAt" = NOW() WHERE id = $2 RETURNING *`, [newAdminNotes, id]);

        res.status(200).json({ success: true, message: 'Visit cancelled successfully', data: updateRes.rows[0] });
    } catch (error) {
        next(error);
    }
};

export const getAgentPendingVisits = async (req, res, next) => {
    try {
        const agentId = req.user.id;
        const { page = 0, size = 20 } = req.query;
        const limit = parseInt(size);
        const offset = parseInt(page) * limit;

        const countQuery = `SELECT COUNT(*) FROM "Visits" WHERE "agentId" = $1 AND status = 'PENDING'`;
        const countRes = await pool.query(countQuery, [agentId]);
        const count = parseInt(countRes.rows[0].count, 10);

        const rowsQuery = `
            SELECT v.*, 
                   json_build_object('id', u.id, 'firstName', u."firstName", 'lastName', u."lastName", 'email', u.email, 'phone', u.phone) as user,
                   json_build_object('id', p.id, 'title', p.title, 'address', p.address) as property
            FROM "Visits" v
            LEFT JOIN "Users" u ON v."userId" = u.id
            LEFT JOIN "Properties" p ON v."propertyId" = p.id
            WHERE v."agentId" = $1 AND v.status = 'PENDING'
            ORDER BY v."preferredVisitTime" ASC
            LIMIT $2 OFFSET $3
        `;
        const rowsRes = await pool.query(rowsQuery, [agentId, limit, offset]);

        const content = rowsRes.rows.map(v => ({
            ...v,
            fullName: v.user ? `${v.user.firstName} ${v.user.lastName}` : 'Unknown Buyer',
            email: v.user ? v.user.email : '',
            phone: v.user ? v.user.phone : '',
            propertyId: v.property ? v.property.id : 'Unknown'
        }));

        res.status(200).json({
            success: true,
            content: content,
            totalElements: count
        });
    } catch (error) {
        next(error);
    }
};

export const confirmVisit = async (req, res, next) => {
    try {
        const { id } = req.params;
        const agentId = req.user.id;

        const visit = await VisitRepository.findById(id);
        if (!visit) return res.status(404).json({ success: false, message: 'Visit not found' });

        if (visit.agentId !== agentId && req.user.userType !== 'admin') {
            return res.status(403).json({ success: false, message: 'Not authorized' });
        }

        const updateRes = await pool.query(`UPDATE "Visits" SET status = 'CONFIRMED', "updatedAt" = NOW() WHERE id = $1 RETURNING *`, [id]);

        res.status(200).json({ success: true, message: 'Visit confirmed', data: updateRes.rows[0] });
    } catch (error) {
        next(error);
    }
};

export const completeVisit = async (req, res, next) => {
    try {
        const { id } = req.params;
        const agentId = req.user.id;

        const visit = await VisitRepository.findById(id);
        if (!visit) return res.status(404).json({ success: false, message: 'Visit not found' });

        if (visit.agentId !== agentId && req.user.userType !== 'admin') {
            return res.status(403).json({ success: false, message: 'Not authorized' });
        }

        const updateRes = await pool.query(`UPDATE "Visits" SET status = 'COMPLETED', "updatedAt" = NOW() WHERE id = $1 RETURNING *`, [id]);

        res.status(200).json({ success: true, message: 'Visit completed', data: updateRes.rows[0] });
    } catch (error) {
        next(error);
    }
};

export const cancelVisitByAgent = async (req, res, next) => {
    try {
        const { id } = req.params;
        const { reason } = req.body;
        const agentId = req.user.id;

        const visit = await VisitRepository.findById(id);
        if (!visit) return res.status(404).json({ success: false, message: 'Visit not found' });

        if (visit.agentId !== agentId && req.user.userType !== 'admin') {
            return res.status(403).json({ success: false, message: 'Not authorized' });
        }

        let newAdminNotes = visit.adminNotes;
        if (reason) {
            const cancellationNote = `[Cancelled by Agent]: ${reason}`;
            newAdminNotes = newAdminNotes ? `${newAdminNotes}\n${cancellationNote}` : cancellationNote;
        }

        const updateRes = await pool.query(`UPDATE "Visits" SET status = 'CANCELLED', "adminNotes" = $1, "updatedAt" = NOW() WHERE id = $2 RETURNING *`, [newAdminNotes, id]);

        res.status(200).json({ success: true, message: 'Visit cancelled', data: updateRes.rows[0] });
    } catch (error) {
        next(error);
    }
};

export const getAgentConfirmedVisits = async (req, res, next) => {
    try {
        const agentId = req.user.id;
        const { page = 0, size = 20 } = req.query;
        const limit = parseInt(size);
        const offset = parseInt(page) * limit;

        const countQuery = `SELECT COUNT(*) FROM "Visits" WHERE "agentId" = $1 AND status = 'CONFIRMED'`;
        const countRes = await pool.query(countQuery, [agentId]);
        const count = parseInt(countRes.rows[0].count, 10);

        const rowsQuery = `
            SELECT v.*, 
                   json_build_object('id', u.id, 'firstName', u."firstName", 'lastName', u."lastName", 'email', u.email, 'phone', u.phone) as user,
                   json_build_object('id', p.id, 'title', p.title, 'address', p.address) as property
            FROM "Visits" v
            LEFT JOIN "Users" u ON v."userId" = u.id
            LEFT JOIN "Properties" p ON v."propertyId" = p.id
            WHERE v."agentId" = $1 AND v.status = 'CONFIRMED'
            ORDER BY v."preferredVisitTime" ASC
            LIMIT $2 OFFSET $3
        `;
        const rowsRes = await pool.query(rowsQuery, [agentId, limit, offset]);

        const content = rowsRes.rows.map(v => ({
            ...v,
            fullName: v.user ? `${v.user.firstName} ${v.user.lastName}` : 'Unknown Buyer',
            email: v.user ? v.user.email : '',
            phone: v.user ? v.user.phone : '',
            propertyId: v.property ? v.property.id : 'Unknown'
        }));

        res.status(200).json({
            success: true,
            content: content,
            totalElements: count
        });
    } catch (error) {
        next(error);
    }
};

export const getOwnerVisits = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { page = 0, size = 10, sort = 'createdAt,desc' } = req.query;
        const limit = parseInt(size);
        const offset = parseInt(page) * limit;
        const [sortField, sortOrder] = sort.split(',');

        const countQuery = `SELECT COUNT(*) FROM "Visits" WHERE "agentId" = $1`;
        const countRes = await pool.query(countQuery, [userId]);
        const count = parseInt(countRes.rows[0].count, 10);

        const rowsQuery = `
            SELECT v.*, 
                   json_build_object('id', u.id, 'firstName', u."firstName", 'lastName', u."lastName", 'email', u.email, 'phone', u.phone, 'avatar', u.avatar) as user,
                   json_build_object('id', p.id, 'title', p.title, 'address', p.address, 'images', p.images) as property
            FROM "Visits" v
            LEFT JOIN "Users" u ON v."userId" = u.id
            LEFT JOIN "Properties" p ON v."propertyId" = p.id
            WHERE v."agentId" = $1
            ORDER BY v."${sortField || 'createdAt'}" ${sortOrder || 'DESC'}
            LIMIT $2 OFFSET $3
        `;
        const rowsRes = await pool.query(rowsQuery, [userId, limit, offset]);

        res.status(200).json({
            success: true,
            data: {
                content: rowsRes.rows,
                totalElements: count,
                totalPages: Math.ceil(count / limit),
                number: parseInt(page)
            }
        });
    } catch (error) {
        next(error);
    }
};
