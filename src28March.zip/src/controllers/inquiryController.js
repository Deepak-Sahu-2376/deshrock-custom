import db from '../models/index.js';
const { pool, Inquiry: InquiryRepository, Property: PropertyRepository, Project: ProjectRepository } = db;
import { sendTemplateEmail } from '../services/emailService.js';

// @desc    Create new inquiry
// @route   POST /api/v1/inquiries
const createInquiry = async (req, res) => {
    try {
        let { propertyId, name, email, phone, message, projectId } = req.body;
        const userId = req.user ? req.user.id : null;

        if ((!propertyId && !projectId) || !name || !email || !phone || !message) {
            return res.status(400).json({ success: false, message: 'All fields are required (propertyId or projectId)' });
        }

        let targetEntity = null;
        let type = '';

        if (propertyId) {
            type = 'Property';
            // Fetch property with user and company user info
            const propQuery = `
                SELECT p.id, p.title, p."userId" as "propUserId", p."companyId",
                       u.email as "userEmail", u."firstName", u."lastName",
                       c."companyName", cu.email as "companyEmail"
                FROM "Properties" p
                LEFT JOIN "Users" u ON p."userId" = u.id
                LEFT JOIN "CompanyProfiles" c ON p."companyId" = c.id
                LEFT JOIN "Users" cu ON c."userId" = cu.id
                WHERE p.id = $1
            `;
            const propRes = await pool.query(propQuery, [propertyId]);
            if (propRes.rows.length > 0) {
                targetEntity = propRes.rows[0];
            }
        } else if (projectId) {
            type = 'Project';
            const projQuery = `
                SELECT p.id, p.name, p."companyId",
                       c."companyName", cu.email as "companyEmail"
                FROM "Projects" p
                LEFT JOIN "CompanyProfiles" c ON p."companyId" = c.id
                LEFT JOIN "Users" cu ON c."userId" = cu.id
                WHERE p.id = $1
            `;
            const projRes = await pool.query(projQuery, [projectId]);
            if (projRes.rows.length > 0) {
                targetEntity = projRes.rows[0];
            }
        }

        if (!targetEntity) {
            return res.status(404).json({ success: false, message: `${type} not found` });
        }

        const inquiry = await InquiryRepository.create({
            propertyId: propertyId || null,
            projectId: projectId || null,
            userId,
            name,
            email,
            phone,
            message
        });

        // Send Email Notification to Owner
        let recipientEmail = null;
        let recipientName = 'Agent';
        const title = targetEntity.title || targetEntity.name; // Property has title, Project has name

        if (type === 'Property') {
            if (targetEntity.userEmail) {
                recipientEmail = targetEntity.userEmail;
                recipientName = targetEntity.firstName;
            } else if (targetEntity.companyEmail) {
                recipientEmail = targetEntity.companyEmail;
                recipientName = targetEntity.companyName;
            }
        } else if (type === 'Project') {
            if (targetEntity.companyEmail) {
                recipientEmail = targetEntity.companyEmail;
                recipientName = targetEntity.companyName;
            }
        }

        if (recipientEmail) {
            const emailData = {
                userName: recipientName,
                propertyTitle: title,
                buyerName: name,
                buyerPhone: phone,
                buyerEmail: email,
                message: message,
                receivedDate: new Date().toLocaleString(),
                viewLink: type === 'Property'
                    ? `${process.env.CLIENT_URL}/property/${targetEntity.id}`
                    : `${process.env.CLIENT_URL}/projects/${targetEntity.id}`
            };
            sendTemplateEmail(recipientEmail, 'ENQUIRY_RECEIVED', emailData).catch(console.error);
        }

        res.status(201).json({
            success: true,
            message: 'Inquiry submitted successfully',
            data: inquiry
        });

    } catch (error) {
        console.error('Error creating inquiry:', error);
        res.status(500).json({ success: false, message: error.message || 'Internal Server Error' });
    }
};

// @desc    Get Inquiries for a specific property (Protected)
// @route   GET /api/v1/inquiries/property/:id
const getInquiriesByProperty = async (req, res) => {
    try {
        const propertyId = req.params.id;

        const inquiriesRes = await pool.query(`SELECT * FROM "Inquiries" WHERE "propertyId" = $1 ORDER BY "createdAt" DESC`, [propertyId]);

        res.status(200).json({
            success: true,
            data: inquiriesRes.rows
        });
    } catch (error) {
        console.error('Error fetching inquiries:', error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

// @desc    Get All Inquiries for Agent (Protected)
// @route   GET /api/v1/inquiries/agent
const getAgentInquiries = async (req, res) => {
    try {
        const agentId = req.user.id;

        // Find inquiries for matching properties based on user role
        let queryStr;
        let queryParams = [];

        if (req.user.userType === 'company') {
            // Company Admin sees all properties associated with their company userId
            // Get companyId for this user
            const companyRes = await pool.query(`SELECT id FROM "CompanyProfiles" WHERE "userId" = $1`, [agentId]);
            if (companyRes.rows.length === 0) {
                return res.status(403).json({ success: false, message: 'Company Profile not found' });
            }
            const companyId = companyRes.rows[0].id;

            queryStr = `
                SELECT i.*, 
                       json_build_object('id', p.id, 'title', p.title, 'user', 
                            json_build_object('firstName', u."firstName", 'lastName', u."lastName", 'email', u.email, 'phone', u.phone)
                       ) as property
                FROM "Inquiries" i
                INNER JOIN "Properties" p ON i."propertyId" = p.id
                LEFT JOIN "Users" u ON p."userId" = u.id
                WHERE p."companyId" = $1
                ORDER BY i."createdAt" DESC
            `;
            queryParams = [companyId];
        } else {
            // Agents (Individual or Company Agent) see only their own properties
            queryStr = `
                SELECT i.*, 
                       json_build_object('id', p.id, 'title', p.title, 'user', 
                            json_build_object('firstName', u."firstName", 'lastName', u."lastName", 'email', u.email, 'phone', u.phone)
                       ) as property
                FROM "Inquiries" i
                INNER JOIN "Properties" p ON i."propertyId" = p.id
                LEFT JOIN "Users" u ON p."userId" = u.id
                WHERE p."userId" = $1
                ORDER BY i."createdAt" DESC
            `;
            queryParams = [agentId];
        }

        const inquiriesRes = await pool.query(queryStr, queryParams);

        res.status(200).json({
            success: true,
            count: inquiriesRes.rows.length,
            data: inquiriesRes.rows
        });

    } catch (error) {
        console.error('Error fetching agent inquiries:', error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

// @desc    Get All Inquiries (Admin) - Paginated
// @route   GET /api/v1/inquiries/admin
const getAllInquiries = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 0;
        const size = parseInt(req.query.size) || 10;
        const { sort } = req.query; // e.g. "createdAt,desc"

        let sortField = 'createdAt';
        let sortOrder = 'DESC';

        if (sort) {
            const [field, direction] = sort.split(',');
            if (field && direction) {
                sortField = field;
                sortOrder = direction.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';
            }
        }

        const countRes = await pool.query(`SELECT COUNT(*) FROM "Inquiries"`);
        const count = parseInt(countRes.rows[0].count, 10);

        const rowsQuery = `
            SELECT i.*,
                   json_build_object('id', p.id, 'title', p.title) as property,
                   json_build_object('id', pr.id, 'name', pr.name) as project
            FROM "Inquiries" i
            LEFT JOIN "Properties" p ON i."propertyId" = p.id
            LEFT JOIN "Projects" pr ON i."projectId" = pr.id
            ORDER BY i."${sortField}" ${sortOrder}
            LIMIT $1 OFFSET $2
        `;
        const rowsRes = await pool.query(rowsQuery, [size, page * size]);

        res.status(200).json({
            success: true,
            content: rowsRes.rows,
            totalPages: Math.ceil(count / size),
            totalElements: count,
            number: page,
            size: size
        });

    } catch (error) {
        console.error('Error fetching all inquiries:', error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

// @desc    Get Inquiries for Owner (Buyer/Agent specific) from properties they own
// @route   GET /api/v1/inquiries/received
const getOwnerInquiries = async (req, res) => {
    try {
        const userId = req.user.id;

        // Find inquiries where property.userId = userId
        const queryStr = `
            SELECT i.*, 
                   json_build_object('id', p.id, 'title', p.title) as property
            FROM "Inquiries" i
            INNER JOIN "Properties" p ON i."propertyId" = p.id
            WHERE p."userId" = $1
            ORDER BY i."createdAt" DESC
        `;
        const inquiriesRes = await pool.query(queryStr, [userId]);

        res.status(200).json({
            success: true,
            count: inquiriesRes.rows.length,
            data: inquiriesRes.rows
        });
    } catch (error) {
        console.error('Error fetching owner inquiries:', error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

export {
    createInquiry,
    getInquiriesByProperty,
    getAgentInquiries,
    getAllInquiries,
    getOwnerInquiries
};
