import db from '../models/index.js';
const { User: UserRepository, pool } = db;
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// @desc    Get current logged in user
// @route   GET /api/v1/users/me
// @access  Private
const getMe = async (req, res) => {
    res.set('Cache-Control', 'no-store');
    try {
        const user = await UserRepository.findById(req.user.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        // Compute derived fields
        // Omit password manually if not already omitted by repository
        const { password, ...userData } = user;

        // Full Name
        userData.fullName = `${user.firstName} ${user.lastName}`;

        // Initials
        if (user.firstName && user.lastName) {
            userData.initials = (user.firstName[0] + user.lastName[0]).toUpperCase();
        } else {
            userData.initials = 'U';
        }

        // Profile Image Map
        userData.profileImageUrl = user.avatar;

        // Account Age
        const createdDate = new Date(user.createdAt);
        const now = new Date();
        const diffTime = Math.abs(now - createdDate);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        if (diffDays > 365) {
            const years = Math.floor(diffDays / 365);
            userData.accountAge = `${years} year${years > 1 ? 's' : ''}`;
        } else if (diffDays > 30) {
            const months = Math.floor(diffDays / 30);
            userData.accountAge = `${months} month${months > 1 ? 's' : ''}`;
        } else {
            userData.accountAge = `${diffDays} day${diffDays !== 1 ? 's' : ''}`;
        }

        // Default/Mock fields for now (can be added to DB later)
        userData.timezone = userData.timezone || 'IST (UTC+05:30)';
        userData.language = userData.language || 'English';
        userData.verificationLevel = user.isVerified ? 'Verified' : 'Basic';
        userData.verificationBadge = user.isVerified ? 'Identity Verified' : 'Pending Verification';
        userData.statusBadge = 'Active';
        userData.profileCompletionPercentage = user.profileComplete ? 100 : 60;
        userData.locationString = 'India';
        userData.rolesList = user.userType ? user.userType.charAt(0).toUpperCase() + user.userType.slice(1) : 'User';
        userData.loginCount = 1; // Mock value

        // Verification Statuses
        userData.isEmailVerified = true; // Assume true for logged in users for now
        userData.isPhoneVerified = !!user.phone; // Assume verified if phone exists for now

        // Date formatting
        userData.lastLoginAt = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }); // Mock for now
        userData.createdAt = new Date(user.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

        res.status(200).json({
            success: true,
            data: userData
        });
    } catch (error) {
        console.error('Error fetching user profile:', error);
        res.status(500).json({
            success: false,
            message: 'Server Error'
        });
    }
};

const uploadAvatar = async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                success: false,
                message: 'No file uploaded'
            });
        }

        // Construct file URL (Relative path)
        const fileUrl = `/uploads/documents/${req.file.filename}`;

        // Update user avatar in DB
        const user = await UserRepository.findById(req.user.id);
        if (user) {
            await pool.query(`UPDATE "Users" SET avatar = $1, "updatedAt" = NOW() WHERE id = $2`, [fileUrl, req.user.id]);
            user.avatar = fileUrl; // update local object for response
        }

        const { password, ...userResponseData } = user;

        res.status(200).json({
            success: true,
            message: 'Avatar uploaded successfully',
            data: {
                profileImageUrl: fileUrl,
                imageUrl: fileUrl,
                user: {
                    ...userResponseData,
                    profileImageUrl: fileUrl
                }
            }
        });

    } catch (error) {
        console.error('Error uploading avatar:', error);
        res.status(500).json({
            success: false,
            message: 'Server Error during upload'
        });
    }
};

const deleteAvatar = async (req, res) => {
    try {
        const user = await UserRepository.findById(req.user.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        // Delete file from filesystem if it exists
        if (user.avatar) {
            // Check if it's a relative path starting with /uploads
            // Assume the DB store relative path like /uploads/documents/filename.ext
            // Remove leading slash if present to join correctly
            const relativePath = user.avatar.startsWith('/') ? user.avatar.slice(1) : user.avatar;

            // app.js: app.use('/uploads', express.static(path.join(__dirname, '../uploads'))); where __dirname is src
            const filePath = path.join(__dirname, '../../', relativePath);

            // Check if file exists and delete
            if (fs.existsSync(filePath)) {
                try {
                    fs.unlinkSync(filePath);
                } catch (err) {
                    console.error('Failed to delete avatar file:', err);
                    // Continue to remove from DB even if file delete fails
                }
            }
        }

        await pool.query(`UPDATE "Users" SET avatar = NULL, "updatedAt" = NOW() WHERE id = $1`, [req.user.id]);
        user.avatar = null;

        const { password, ...userResponseData } = user;

        res.status(200).json({
            success: true,
            message: 'Avatar removed successfully',
            data: {
                profileImageUrl: null,
                user: {
                    ...userResponseData,
                    profileImageUrl: null
                }
            }
        });

    } catch (error) {
        console.error('Error deleting avatar:', error);
        res.status(500).json({
            success: false,
            message: 'Server Error during deletion'
        });
    }
};

export {
    getMe,
    uploadAvatar,
    deleteAvatar
};
