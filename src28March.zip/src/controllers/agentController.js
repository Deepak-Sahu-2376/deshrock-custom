import db from '../models/index.js';
const { pool, Otp: OtpRepository, User: UserRepository, AgentProfile: AgentProfileRepository, CompanyProfile: CompanyProfileRepository, Document: DocumentRepository } = db;
import sendEmail from '../services/emailService.js';
import bcrypt from 'bcryptjs';

// @desc    Send OTP for Agent Reg
// @route   POST /api/v1/agents/register/send-otp
const sendAgentOtp = async (req, res) => {
    const email = req.query.email || req.body.email;
    if (!email) return res.status(400).json({ success: false, message: 'Email is required' });

    try {
        const userRes = await pool.query('SELECT * FROM "Users" WHERE email = $1', [email]);
        const userExists = userRes.rows[0];

        if (userExists && userExists.isVerified) {
            return res.status(400).json({ success: false, message: 'Email already registered' });
        }

        const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
        const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

        await OtpRepository.create({
            identifier: email,
            code: otpCode,
            expiresAt,
            purpose: 'agent_registration'
        });

        await sendEmail(email, 'Agent Registration OTP', `Your OTP is ${otpCode}`);
        res.json({ success: true, message: 'OTP sent to agent email.' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Register Agent
// @route   POST /api/v1/agents/register
const registerAgent = async (req, res) => {
    const {
        firstName, lastName, email, phone, password, otpCode,
        city, state, country, address, pincode,
        specialization, experienceYears, bio, serviceAreas, languages,
        dob,
        agentType, companyId, companyName,
        allowMarketingEmails, allowSmsNotifications, profileVisibility,
        acceptTerms, acceptPrivacyPolicy
    } = req.body;

    console.log('Register Agent Request Body:', JSON.stringify(req.body, null, 2));
    console.log('Register Agent Request Files:', req.files);

    try {
        const otpRes = await pool.query(`
            SELECT * FROM "Otps" 
            WHERE identifier = $1 AND code = $2 AND "isUsed" = false AND purpose = 'agent_registration' AND "expiresAt" > NOW()
        `, [email, otpCode]);
        const otp = otpRes.rows[0];

        if (!otp) return res.status(400).json({ success: false, message: 'Invalid or expired OTP' });

        // Validate Company if Company Agent
        if (agentType === 'COMPANY_AGENT') {
            if (!companyId) {
                return res.status(400).json({ success: false, message: 'Company selection is required for Company Agents' });
            }

            const companyRes = await pool.query(`SELECT * FROM "CompanyProfiles" WHERE id = $1 AND status = 'approved'`, [companyId]);
            const companyProfile = companyRes.rows[0];

            if (!companyProfile) {
                return res.status(400).json({ success: false, message: 'Invalid or unapproved company selected' });
            }
        }

        // Create User
        // agentType logic: If COMPANY_AGENT, userType could be 'company_agent' or just 'agent'. 
        // Docs say userType is checked. Let's stick to 'agent' or 'company_agent'.
        // Check for existing user
        const userRes = await pool.query('SELECT * FROM "Users" WHERE email = $1', [email]);
        let newUser = userRes.rows[0];

        if (newUser && newUser.isVerified) {
            return res.status(400).json({ success: false, message: 'User already registered and verified.' });
        }

        const hashedPassword = password ? await bcrypt.hash(password, 10) : null;
        const assignedUserType = agentType === 'COMPANY_AGENT' ? 'company_agent' : 'agent';
        let userId;

        if (newUser && !newUser.isVerified) {
            const updateQuery = `
                UPDATE "Users" 
                SET "firstName" = $1, "lastName" = $2, password = $3, phone = $4, "userType" = $5, "isVerified" = true,
                    "acceptTerms" = $6, "acceptPrivacyPolicy" = $7, "allowMarketingEmails" = $8, "allowSmsNotifications" = $9, "updatedAt" = NOW()
                WHERE id = $10 RETURNING id
             `;
            const updatedUser = await pool.query(updateQuery, [
                firstName, lastName, hashedPassword || newUser.password, phone, assignedUserType,
                acceptTerms, acceptPrivacyPolicy, allowMarketingEmails, allowSmsNotifications, newUser.id
            ]);
            userId = updatedUser.rows[0].id;
        } else {
            const insertQuery = `
                INSERT INTO "Users" 
                (identifier, email, "firstName", "lastName", password, phone, "userType", "isVerified", 
                 "acceptTerms", "acceptPrivacyPolicy", "allowMarketingEmails", "allowSmsNotifications", "createdAt", "updatedAt")
                VALUES ($1, $2, $3, $4, $5, $6, $7, true, $8, $9, $10, $11, NOW(), NOW()) RETURNING id
             `;
            const insertedUser = await pool.query(insertQuery, [
                email, email, firstName, lastName, hashedPassword, phone, assignedUserType,
                acceptTerms, acceptPrivacyPolicy, allowMarketingEmails, allowSmsNotifications
            ]);
            userId = insertedUser.rows[0].id;
        }

        // Agent Profile logic
        const profileRes = await pool.query('SELECT * FROM "AgentProfiles" WHERE "userId" = $1', [userId]);
        const existingProfile = profileRes.rows[0];
        const status = agentType === 'COMPANY_AGENT' ? 'pending_company_approval' : 'pending';

        if (existingProfile) {
            const updateProfileQuery = `
                 UPDATE "AgentProfiles" SET
                 city = $1, state = $2, country = $3, address = $4, pincode = $5,
                 specialization = $6, "experienceYears" = $7, bio = $8, "serviceAreas" = $9, languages = $10,
                 dob = $11, "agentType" = $12, "companyId" = $13, "companyName" = $14, "profileVisibility" = $15, status = $16, "updatedAt" = NOW()
                 WHERE "userId" = $17
            `;
            await pool.query(updateProfileQuery, [
                city, state, country, address, pincode,
                specialization, experienceYears, bio, serviceAreas, languages,
                dob, agentType, companyId, companyName, profileVisibility, status, userId
            ]);
        } else {
            const insertProfileQuery = `
                 INSERT INTO "AgentProfiles" 
                 ("userId", city, state, country, address, pincode, specialization, "experienceYears", bio, "serviceAreas", languages,
                  dob, "agentType", "companyId", "companyName", "profileVisibility", status, "createdAt", "updatedAt")
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, NOW(), NOW())
            `;
            await pool.query(insertProfileQuery, [
                userId, city, state, country, address, pincode, specialization, experienceYears, bio, serviceAreas, languages,
                dob, agentType, companyId, companyName, profileVisibility, status
            ]);
        }

        // Save Documents if any
        if (req.files && req.files.length > 0) {
            const documentPromises = req.files.map(file => {
                return DocumentRepository.create({
                    entityId: userId,
                    entityType: 'AGENT',
                    documentType: 'registration_document',
                    fileName: file.originalname,
                    fileUrl: `/uploads/documents/${file.filename}`,
                    mimeType: file.mimetype,
                    fileSize: file.size,
                    status: 'PENDING'
                });
            });
            await Promise.all(documentPromises);
        }

        await pool.query(`UPDATE "Otps" SET "isUsed" = true, "updatedAt" = NOW() WHERE id = $1`, [otp.id]);

        res.status(201).json({ success: true, message: 'Agent registered successfully. Pending approval.' });

    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Get All Agents (Admin)
// @route   GET /api/v1/agents
const getAllAgents = async (req, res) => {
    try {
        const rowsQuery = `
            SELECT a.*, 
                   json_build_object('email', u.email, 'firstName', u."firstName", 'lastName', u."lastName", 'phone', u.phone, 'isVerified', u."isVerified") as user
            FROM "AgentProfiles" a
            LEFT JOIN "Users" u ON a."userId" = u.id
            ORDER BY a."createdAt" DESC
        `;
        const { rows } = await pool.query(rowsQuery);

        res.status(200).json({
            success: true,
            data: rows
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Get All Public Agents
// @route   GET /api/v1/public/agents
const getPublicAgents = async (req, res) => {
    try {
        const page = req.query.page ? parseInt(req.query.page) : 0;
        const size = req.query.size ? parseInt(req.query.size) : 10;
        const limit = size;
        const offset = page * limit;

        const countQuery = `
            SELECT COUNT(*) 
            FROM "AgentProfiles" a
            WHERE a.status = 'approved' AND a."profileVisibility" = true
        `;
        const countResult = await pool.query(countQuery);
        const totalElements = parseInt(countResult.rows[0].count, 10);

        const rowsQuery = `
            SELECT a.*, 
                   json_build_object('email', u.email, 'firstName', u."firstName", 'lastName', u."lastName", 'phone', u.phone) as user,
                   json_build_object('companyName', c."companyName") as company
            FROM "AgentProfiles" a
            LEFT JOIN "Users" u ON a."userId" = u.id
            LEFT JOIN "CompanyProfiles" c ON a."companyId" = c.id
            WHERE a.status = 'approved' AND a."profileVisibility" = true
            ORDER BY a."createdAt" DESC
            LIMIT $1 OFFSET $2
        `;
        const { rows } = await pool.query(rowsQuery, [limit, offset]);

        res.status(200).json({
            success: true,
            content: rows,
            data: {
                content: rows,
                totalPages: Math.ceil(totalElements / limit),
                totalElements
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get Public Agent By ID
// @route   GET /api/v1/public/agents/:id
const getPublicAgentById = async (req, res) => {
    try {
        const agentId = req.params.id;

        const rowsQuery = `
            SELECT a.*, 
                   json_build_object('email', u.email, 'firstName', u."firstName", 'lastName', u."lastName", 'phone', u.phone) as user,
                   json_build_object('companyName', c."companyName") as company
            FROM "AgentProfiles" a
            LEFT JOIN "Users" u ON a."userId" = u.id
            LEFT JOIN "CompanyProfiles" c ON a."companyId" = c.id
            WHERE a.id = $1 AND a.status = 'approved' AND a."profileVisibility" = true
        `;
        const { rows } = await pool.query(rowsQuery, [agentId]);

        if (rows.length === 0) {
            return res.status(404).json({ success: false, message: 'Agent not found' });
        }

        res.status(200).json({
            success: true,
            data: rows[0]
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

export { sendAgentOtp, registerAgent, getAllAgents, getPublicAgents, getPublicAgentById };
