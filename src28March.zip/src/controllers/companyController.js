import db from '../models/index.js';
const { pool, Otp: OtpRepository, User: UserRepository, CompanyProfile: CompanyProfileRepository, AgentProfile: AgentProfileRepository, Project: ProjectRepository, Property: PropertyRepository, Document: DocumentRepository } = db;
import { sendTemplateEmail } from '../services/emailService.js';
import bcrypt from 'bcryptjs';

// @desc    Send OTP for Company Registration
// @route   POST /api/v1/companies/register/send-otp
const sendCompanyOtp = async (req, res) => {
    const email = req.query.email || req.body.email;
    if (!email) return res.status(400).json({ success: false, message: 'Email is required' });

    try {
        const userRes = await pool.query('SELECT * FROM "Users" WHERE email ILIKE $1', [email]);
        const userExists = userRes.rows[0];

        if (userExists && userExists.isVerified) {
            return res.status(400).json({ success: false, message: 'Email already registered' });
        }

        const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
        const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

        await OtpRepository.create({
            identifier: email,
            code: otpCode,
            expiresAt,
            purpose: 'company_registration'
        });

        const otpData = {
            userName: 'User',
            otp: otpCode
        };
        await sendTemplateEmail(email, 'OTP_LOGIN', otpData);

        res.json({ success: true, message: 'OTP sent to company email.' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Register Company (Verify OTP & Create)
// @route   POST /api/v1/companies/register
const registerCompany = async (req, res) => {
    const {
        email, otpCode, password, confirmPassword,
        companyName, companyType, registrationNumber, establishmentYear,
        contactPersonName, contactPersonDesignation, phone, alternateEmail,
        address, city, state, country, pincode,
        description, serviceAreas, specializations,
        gstNumber, panNumber, licenseNumber, licenseAuthority, licenseExpiryDate,
        website, employeeCount,
        acceptTerms, acceptPrivacyPolicy, allowMarketingEmails, allowSmsNotifications
    } = req.body;

    if (password !== confirmPassword) return res.status(400).json({ success: false, message: 'Passwords do not match' });

    try {
        const otpRes = await pool.query(`
            SELECT * FROM "Otps" 
            WHERE identifier ILIKE $1 AND code = $2 AND "isUsed" = false AND purpose = 'company_registration' AND "expiresAt" > NOW()
        `, [email, otpCode]);
        const otp = otpRes.rows[0];

        if (!otp) return res.status(400).json({ success: false, message: 'Invalid or expired OTP' });

        const userRes = await pool.query('SELECT * FROM "Users" WHERE email ILIKE $1', [email]);
        let newUser = userRes.rows[0];

        if (newUser && newUser.isVerified) {
            return res.status(400).json({ success: false, message: 'User already registered and verified.' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        let userId;

        const firstName = contactPersonName.split(' ')[0] || 'Company';
        const lastName = contactPersonName.split(' ').slice(1).join(' ') || 'Admin';

        if (newUser && !newUser.isVerified) {
            const updateQuery = `
                UPDATE "Users" 
                SET "firstName" = $1, "lastName" = $2, password = $3, phone = $4, "userType" = 'company', "isVerified" = true,
                    "acceptTerms" = $5, "acceptPrivacyPolicy" = $6, "allowMarketingEmails" = $7, "allowSmsNotifications" = $8, "updatedAt" = NOW()
                WHERE id = $9 RETURNING id
            `;
            const updatedUser = await pool.query(updateQuery, [
                firstName, lastName, hashedPassword, phone, acceptTerms, acceptPrivacyPolicy, allowMarketingEmails, allowSmsNotifications, newUser.id
            ]);
            userId = updatedUser.rows[0].id;
        } else {
            const insertQuery = `
                INSERT INTO "Users" 
                (identifier, email, "firstName", "lastName", password, phone, "userType", "isVerified", 
                 "acceptTerms", "acceptPrivacyPolicy", "allowMarketingEmails", "allowSmsNotifications", "createdAt", "updatedAt")
                VALUES ($1, $2, $3, $4, $5, $6, 'company', true, $7, $8, $9, $10, NOW(), NOW()) RETURNING id
            `;
            const insertedUser = await pool.query(insertQuery, [
                email, email, firstName, lastName, hashedPassword, phone, acceptTerms, acceptPrivacyPolicy, allowMarketingEmails, allowSmsNotifications
            ]);
            userId = insertedUser.rows[0].id;
        }

        const profileRes = await pool.query('SELECT id FROM "CompanyProfiles" WHERE "userId" = $1', [userId]);
        const existingProfile = profileRes.rows[0];

        if (existingProfile) {
            const updateProfileQuery = `
                 UPDATE "CompanyProfiles" SET
                 "companyName" = $1, "companyType" = $2, "registrationNumber" = $3, "establishmentYear" = $4,
                 "contactPersonName" = $5, "contactPersonDesignation" = $6, "alternateEmail" = $7,
                 address = $8, city = $9, state = $10, country = $11, pincode = $12,
                 description = $13, "serviceAreas" = $14, specializations = $15,
                 "gstNumber" = $16, "panNumber" = $17, "licenseNumber" = $18, "licenseAuthority" = $19, "licenseExpiryDate" = $20,
                 website = $21, "employeeCount" = $22, status = 'pending', "updatedAt" = NOW()
                 WHERE "userId" = $23
            `;
            await pool.query(updateProfileQuery, [
                companyName, companyType, registrationNumber, establishmentYear,
                contactPersonName, contactPersonDesignation, alternateEmail,
                address, city, state, country, pincode,
                description, serviceAreas, specializations,
                gstNumber, panNumber, licenseNumber, licenseAuthority, licenseExpiryDate || null,
                website, employeeCount, userId
            ]);
        } else {
            const insertProfileQuery = `
                 INSERT INTO "CompanyProfiles" 
                 ("userId", "companyName", "companyType", "registrationNumber", "establishmentYear",
                  "contactPersonName", "contactPersonDesignation", "alternateEmail",
                  address, city, state, country, pincode,
                  description, "serviceAreas", specializations,
                  "gstNumber", "panNumber", "licenseNumber", "licenseAuthority", "licenseExpiryDate",
                  website, "employeeCount", status, "createdAt", "updatedAt")
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, 'pending', NOW(), NOW())
            `;
            await pool.query(insertProfileQuery, [
                userId, companyName, companyType, registrationNumber, establishmentYear,
                contactPersonName, contactPersonDesignation, alternateEmail,
                address, city, state, country, pincode,
                description, serviceAreas, specializations,
                gstNumber, panNumber, licenseNumber, licenseAuthority, licenseExpiryDate || null,
                website, employeeCount
            ]);
        }

        if (req.files && req.files.length > 0) {
            const documentPromises = req.files.map(file => {
                return DocumentRepository.create({
                    entityId: userId,
                    entityType: 'COMPANY',
                    documentType: 'registration_document',
                    fileName: file.originalname,
                    fileUrl: `/uploads/documents/${file.filename}`,
                    mimeType: file.mimetype,
                    fileSize: file.size,
                    status: 'PENDING'
                });
            });
            await Promise.all(documentPromises);
        }

        await pool.query(`UPDATE "Otps" SET "isUsed" = true, "updatedAt" = NOW() WHERE id = $1`, [otp.id]);

        const regData = {
            userName: firstName,
            companyName: companyName
        };
        sendTemplateEmail(email, 'COMPANY_REGISTRATION_SUBMITTED', regData).catch(console.error);

        res.status(201).json({ success: true, message: 'Company registered successfully. Pending approval.' });

    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Get Companies Dropdown
// @route   GET /api/v1/companies/dropdown
const getCompaniesDropdown = async (req, res) => {
    try {
        console.log("Fetching companies dropdown...");
        const { rows } = await pool.query(`SELECT id, "companyName", status FROM "CompanyProfiles" WHERE status = 'approved'`);
        res.json({ success: true, data: rows });
    } catch (error) {
        console.error("Error fetching companies dropdown:", error);
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Get Verified Companies Count
// @route   GET /api/v1/companies/statistics/verified
const getVerifiedCompaniesCount = async (req, res) => {
    try {
        const { rows } = await pool.query(`SELECT COUNT(*) FROM "CompanyProfiles" WHERE status = 'approved'`);
        res.json({ verified: parseInt(rows[0].count, 10) });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Get Pending Companies Count
// @route   GET /api/v1/companies/statistics/pending
const getPendingCompaniesCount = async (req, res) => {
    try {
        const { rows } = await pool.query(`SELECT COUNT(*) FROM "CompanyProfiles" WHERE status = 'pending'`);
        res.json({ pending: parseInt(rows[0].count, 10) });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Get All Companies (Admin)
// @route   GET /api/v1/companies
const getAllCompanies = async (req, res) => {
    try {
        const query = `
            SELECT c.*, 
                   json_build_object('email', u.email, 'phone', u.phone) as user
            FROM "CompanyProfiles" c
            LEFT JOIN "Users" u ON c."userId" = u.id
            ORDER BY c."createdAt" DESC
        `;
        const { rows } = await pool.query(query);

        const flatCompanies = rows.map(company => ({
            ...company,
            email: company.user?.email,
            phone: company.user?.phone
        }));

        res.status(200).json({
            success: true,
            data: flatCompanies
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Get Agent Requests for Company
// @route   GET /api/v1/companies/agent-requests
const getAgentRequests = async (req, res) => {
    try {
        const userId = req.user.id;
        const companyRes = await pool.query('SELECT id FROM "CompanyProfiles" WHERE "userId" = $1', [userId]);

        if (companyRes.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'Company profile not found' });
        }

        const companyId = companyRes.rows[0].id;

        const query = `
            SELECT a.*, 
                   json_build_object('firstName', u."firstName", 'lastName', u."lastName", 'email', u.email, 'phone', u.phone) as user
            FROM "AgentProfiles" a
            LEFT JOIN "Users" u ON a."userId" = u.id
            WHERE a."companyId" = $1 AND a.status = 'pending_company_approval'
        `;
        const { rows } = await pool.query(query, [companyId]);

        const flatRequests = rows.map(agent => ({
            ...agent,
            firstName: agent.user?.firstName,
            lastName: agent.user?.lastName,
            email: agent.user?.email,
            phone: agent.user?.phone
        }));

        res.json({ success: true, data: flatRequests });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Approve Agent Request
// @route   POST /api/v1/companies/agent-requests/:id/approve
const approveAgentRequest = async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.id;
        const companyRes = await pool.query('SELECT id FROM "CompanyProfiles" WHERE "userId" = $1', [userId]);

        if (companyRes.rows.length === 0) return res.status(404).json({ success: false, message: 'Company not found' });
        const companyId = companyRes.rows[0].id;

        const updateRes = await pool.query(`
            UPDATE "AgentProfiles" SET status = 'pending', "updatedAt" = NOW() 
            WHERE id = $1 AND "companyId" = $2 AND status = 'pending_company_approval' RETURNING id
        `, [id, companyId]);

        if (updateRes.rowCount === 0) return res.status(404).json({ success: false, message: 'Request not found' });

        res.json({ success: true, message: 'Agent approved. Now pending Admin approval.' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Reject Agent Request
// @route   POST /api/v1/companies/agent-requests/:id/reject
const rejectAgentRequest = async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.id;
        const companyRes = await pool.query('SELECT id FROM "CompanyProfiles" WHERE "userId" = $1', [userId]);

        if (companyRes.rows.length === 0) return res.status(404).json({ success: false, message: 'Company not found' });
        const companyId = companyRes.rows[0].id;

        const updateRes = await pool.query(`
            UPDATE "AgentProfiles" SET status = 'rejected', "updatedAt" = NOW() 
            WHERE id = $1 AND "companyId" = $2 AND status = 'pending_company_approval' RETURNING id
        `, [id, companyId]);

        if (updateRes.rowCount === 0) return res.status(404).json({ success: false, message: 'Request not found' });

        res.json({ success: true, message: 'Agent request rejected.' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Get Active Agents for Company
// @route   GET /api/v1/companies/agents
const getCompanyAgents = async (req, res) => {
    try {
        const userId = req.user.id;
        const companyRes = await pool.query('SELECT id FROM "CompanyProfiles" WHERE "userId" = $1', [userId]);

        if (companyRes.rows.length === 0) return res.status(404).json({ success: false, message: 'Company not found' });
        const companyId = companyRes.rows[0].id;

        const query = `
            SELECT a.*, 
                   json_build_object('firstName', u."firstName", 'lastName', u."lastName", 'email', u.email, 'phone', u.phone) as user
            FROM "AgentProfiles" a
            LEFT JOIN "Users" u ON a."userId" = u.id
            WHERE a."companyId" = $1 AND a.status = 'approved'
        `;
        const { rows } = await pool.query(query, [companyId]);

        const flatAgents = rows.map(agent => ({
            ...agent,
            firstName: agent.user?.firstName,
            lastName: agent.user?.lastName,
            email: agent.user?.email,
            phone: agent.user?.phone
        }));

        res.json({ success: true, data: flatAgents });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Get Company Dashboard Stats
// @route   GET /api/v1/companies/statistics/dashboard
const getDashboardStats = async (req, res) => {
    try {
        let companyId;

        if (req.user.userType === 'company') {
            const companyRes = await pool.query('SELECT id FROM "CompanyProfiles" WHERE "userId" = $1', [req.user.id]);
            if (companyRes.rows.length === 0) return res.status(404).json({ success: false, message: 'Company not found' });
            companyId = companyRes.rows[0].id;
        } else if (req.user.userType === 'company_agent') {
            const agentRes = await pool.query('SELECT "companyId" FROM "AgentProfiles" WHERE "userId" = $1', [req.user.id]);
            if (agentRes.rows.length === 0) return res.status(404).json({ success: false, message: 'Agent not found' });
            companyId = agentRes.rows[0].companyId;
        } else {
            return res.status(403).json({ success: false, message: 'Not authorized' });
        }

        const projectCountRes = await pool.query(`SELECT COUNT(*) FROM "Projects" WHERE "companyId" = $1`, [companyId]);
        const totalProjects = parseInt(projectCountRes.rows[0].count, 10);

        const agentCountRes = await pool.query(`SELECT COUNT(*) FROM "AgentProfiles" WHERE "companyId" = $1 AND status = 'approved'`, [companyId]);
        const totalAgents = parseInt(agentCountRes.rows[0].count, 10);

        const propertyCountRes = await pool.query(`SELECT COUNT(*) FROM "Properties" WHERE "companyId" = $1 AND status = 'APPROVED'`, [companyId]);
        const activeListings = parseInt(propertyCountRes.rows[0].count, 10);

        const pendingAgentRes = await pool.query(`SELECT COUNT(*) FROM "AgentProfiles" WHERE "companyId" = $1 AND status = 'pending_company_approval'`, [companyId]);
        const pendingAgents = parseInt(pendingAgentRes.rows[0].count, 10);

        // Sum viewCount
        const viewsRes = await pool.query(`SELECT SUM("viewCount") as total_views FROM "Properties" WHERE "companyId" = $1`, [companyId]);
        const totalViews = parseInt(viewsRes.rows[0].total_views || 0, 10);

        res.json({
            success: true,
            data: {
                totalProjects,
                totalAgents,
                activeListings,
                pendingAgents,
                totalViews,
                totalLeads: 0 // Placeholder
            }
        });

    } catch (error) {
        console.error('Error fetching dashboard stats:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

export {
    sendCompanyOtp,
    registerCompany,
    getCompaniesDropdown,
    getVerifiedCompaniesCount,
    getPendingCompaniesCount,
    getAllCompanies,
    getAgentRequests,
    approveAgentRequest,
    rejectAgentRequest,
    getCompanyAgents,
    getDashboardStats
};
