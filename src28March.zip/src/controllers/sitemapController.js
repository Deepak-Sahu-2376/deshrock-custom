import { SitemapStream, streamToPromise } from 'sitemap';
import { createGzip } from 'zlib';
import db from '../models/index.js';
const { pool } = db;

const encodeUrlPath = (str) => encodeURIComponent(str).replace(/%20/g, '-');

export const getSitemap = async (req, res) => {
    try {
        res.header('Content-Type', 'application/xml');
        res.header('Content-Encoding', 'gzip');

        const sitemap = new SitemapStream({ hostname: process.env.CLIENT_URL || 'https://deshrock.com' });
        const pipeline = sitemap.pipe(createGzip());

        // Static URLs
        sitemap.write({ url: '/', changefreq: 'daily', priority: 1.0 });
        sitemap.write({ url: '/about', changefreq: 'monthly', priority: 0.8 });
        sitemap.write({ url: '/properties', changefreq: 'daily', priority: 0.9 });
        sitemap.write({ url: '/projects', changefreq: 'daily', priority: 0.9 });
        sitemap.write({ url: '/contact', changefreq: 'yearly', priority: 0.7 });

        // Dynamic Properties
        const propertiesRes = await pool.query(`SELECT id, city, title, "updatedAt" FROM "Properties" WHERE status = 'APPROVED'`);
        const properties = propertiesRes.rows;

        properties.forEach(property => {
            const citySlug = property.city ? property.city.toLowerCase().replace(/\s+/g, '-') : 'city';
            const titleSlug = property.title ? property.title.toLowerCase().replace(/\s+/g, '-') : 'property';
            sitemap.write({
                url: `/property/${encodeUrlPath(titleSlug)}/${encodeUrlPath(citySlug)}/${property.id}`,
                lastmod: property.updatedAt,
                changefreq: 'weekly',
                priority: 0.8
            });
        });

        // Dynamic Projects
        const projectsRes = await pool.query(`SELECT id, city, name, "updatedAt" FROM "Projects" WHERE "approvalStatus" = 'APPROVED'`);
        const projects = projectsRes.rows;

        projects.forEach(project => {
            const citySlug = project.city ? project.city.toLowerCase().replace(/\s+/g, '-') : 'city';
            const titleSlug = project.name ? project.name.toLowerCase().replace(/\s+/g, '-') : 'project';
            sitemap.write({
                url: `/projects/${encodeUrlPath(titleSlug)}/${encodeUrlPath(citySlug)}/${project.id}`,
                lastmod: project.updatedAt,
                changefreq: 'weekly',
                priority: 0.8
            });
        });

        // City Categories for Properties
        const propertyCitiesRes = await pool.query(`SELECT DISTINCT city FROM "Properties" WHERE status = 'APPROVED' AND city IS NOT NULL`);
        const propertyCities = propertyCitiesRes.rows;

        propertyCities.forEach(p => {
            const city = p.city;
            if (city) {
                sitemap.write({
                    url: `/properties?city=${encodeURIComponent(city)}`,
                    changefreq: 'daily',
                    priority: 0.8
                });
            }
        });

        // City Categories for Projects
        const projectCitiesRes = await pool.query(`SELECT DISTINCT city FROM "Projects" WHERE "approvalStatus" = 'APPROVED' AND city IS NOT NULL`);
        const projectCities = projectCitiesRes.rows;

        projectCities.forEach(p => {
            const city = p.city;
            if (city) {
                sitemap.write({
                    url: `/projects?city=${encodeURIComponent(city)}`,
                    changefreq: 'daily',
                    priority: 0.8
                });
            }
        });

        sitemap.end();
        pipeline.pipe(res).on('error', (e) => { throw e });

    } catch (e) {
        console.error("Sitemap Generation Error:", e);
        res.status(500).end();
    }
};
