import jwt from 'jsonwebtoken';
import db from '../models/index.js';
const { pool, User: UserRepository } = db;

const protect = async (req, res, next) => {
    let token;

    if (
        req.headers.authorization &&
        req.headers.authorization.startsWith('Bearer')
    ) {
        try {
            token = req.headers.authorization.split(' ')[1];
            const decoded = jwt.verify(token, process.env.JWT_SECRET);

            const userRes = await pool.query('SELECT * FROM "Users" WHERE id = $1', [decoded.id]);
            const user = userRes.rows[0];

            if (!user) {
                return res.status(401).json({ success: false, message: 'Not authorized, user not found' });
            }

            // Fetch profiles if needed
            let companyProfile = null;
            let agentProfile = null;

            if (user.userType === 'company') {
                const companyRes = await pool.query('SELECT * FROM "CompanyProfiles" WHERE "userId" = $1', [user.id]);
                companyProfile = companyRes.rows[0];
            } else if (user.userType === 'agent' || user.userType === 'company_agent') {
                const agentRes = await pool.query('SELECT * FROM "AgentProfiles" WHERE "userId" = $1', [user.id]);
                agentProfile = agentRes.rows[0];
            }

            delete user.password;

            req.user = {
                ...user,
                companyProfile,
                agentProfile
            };

            next();
        } catch (error) {
            console.error('Auth Error:', error.message);
            res.status(401).json({ success: false, message: 'Not authorized, token failed' });
        }
    } else {
        res.status(401).json({ success: false, message: 'Not authorized, no token' });
    }
};

const authorize = (...roles) => {
    return (req, res, next) => {
        if (!roles.includes(req.user.userType)) {
            return res.status(403).json({ success: false, message: `User role ${req.user.userType} is not authorized` });
        }
        next();
    };
};

const optionalProtect = async (req, res, next) => {
    let token;

    if (
        req.headers.authorization &&
        req.headers.authorization.startsWith('Bearer')
    ) {
        try {
            token = req.headers.authorization.split(' ')[1];
            const decoded = jwt.verify(token, process.env.JWT_SECRET);

            const userRes = await pool.query('SELECT * FROM "Users" WHERE id = $1', [decoded.id]);
            const user = userRes.rows[0];
            if (user) {
                delete user.password;
                req.user = user;
            }
        } catch (error) {
            console.error('Optional Auth Error:', error.message);
            // Do not fail, just don't set user
        }
    }
    next();
};

export { protect, authorize, optionalProtect };
