import bcrypt from 'bcryptjs';
import db from '../models/index.js';

const { pool } = db;

const seedDatabase = async () => {
    try {
        console.log('Seeding Database...');
        const client = await pool.connect();

        // Check if admin exists
        const adminEmail = 'deshrockpvt.ltd@gmail.com';
        const checkAdminRes = await client.query('SELECT id FROM "Users" WHERE email = $1', [adminEmail]);

        if (checkAdminRes.rows.length === 0) {
            console.log('Creating Admin user...');
            const salt = await bcrypt.genSalt(10);
            const hashedPassword = await bcrypt.hash('Suraj@11', salt);

            await client.query(`
                INSERT INTO "Users" (
                    identifier, email, "firstName", "lastName", password, "userType", "isVerified",
                    "acceptTerms", "acceptPrivacyPolicy", "createdAt", "updatedAt"
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW(), NOW())
            `, [adminEmail, adminEmail, 'Super', 'Admin', hashedPassword, 'admin', true, true, true]);

            console.log('Admin user created successfully.');
        } else {
            console.log('Admin user already exists.');
        }

        // Add additional seeders here if needed.
        // For example, creating mock properties, mock projects, etc.

        client.release();
        console.log('Database Seeding Completed.');
        process.exit(0);

    } catch (error) {
        console.error('Database Seeding Failed:', error);
        process.exit(1);
    }
};

seedDatabase();
