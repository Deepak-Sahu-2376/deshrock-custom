import pg from 'pg';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const { Client } = pg;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const initializeDatabase = async () => {
    const dbUrl = process.env.DATABASE_URL;
    if (!dbUrl) {
        console.error('DATABASE_URL is not defined in .env');
        process.exit(1);
    }

    // Parse DB Name from URL
    // Format: postgresql://user:pass@host:port/dbname
    const dbName = dbUrl.split('/').pop();
    const connectionStringWithoutDb = dbUrl.substring(0, dbUrl.lastIndexOf('/'));

    // 1. Create Database if not exists
    console.log(`Checking if database '${dbName}' exists...`);
    const initialClient = new Client({ connectionString: connectionStringWithoutDb + '/postgres' }); // Connect to default 'postgres' db

    try {
        await initialClient.connect();
        const res = await initialClient.query(`SELECT 1 FROM pg_database WHERE datname = $1`, [dbName]);

        if (res.rowCount === 0) {
            console.log(`Database '${dbName}' does not exist. Creating...`);
            await initialClient.query(`CREATE DATABASE "${dbName}"`);
            console.log(`Database '${dbName}' created successfully.`);
        } else {
            console.log(`Database '${dbName}' already exists.`);
        }
    } catch (error) {
        console.error('Error checking/creating database:', error);
        process.exit(1);
    } finally {
        await initialClient.end();
    }

    // 2. Sync Tables using schema.sql
    console.log('Syncing database tables using schema.sql...');

    const client = new Client({ connectionString: dbUrl });

    try {
        await client.connect();
        const schemaPath = path.join(__dirname, 'schema.sql');
        const schemaSql = fs.readFileSync(schemaPath, 'utf8');

        await client.query(schemaSql);

        console.log('Database tables completely initialized from schema.sql successfully.');
        process.exit(0);
    } catch (error) {
        console.error('Error executing schema.sql:', error);
        process.exit(1);
    } finally {
        await client.end();
    }
};

initializeDatabase();
