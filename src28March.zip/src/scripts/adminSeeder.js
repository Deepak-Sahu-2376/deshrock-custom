import db from '../models/index.js';
const { User: UserRepository } = db;
import bcrypt from 'bcryptjs';

const seedAdmin = async () => {
    try {
        const adminEmail = 'deshrockpvt.ltd@gmail.com';
        const existingAdmin = await UserRepository.findByEmail(adminEmail);

        if (existingAdmin) {
            console.log('Admin user already exists.');
            return;
        }

        // Create Admin
        // Password hashing is handled by the model hook, so just pass the plain password
        await UserRepository.create({
            identifier: adminEmail,
            email: adminEmail,
            firstName: 'Super',
            lastName: 'Admin',
            password: 'Suraj@11', // Will be hashed inside UserRepository.create if implemented correctly, but standard is there. Let's check authController for register. Wait, we should hash here if repo doesn't!
            userType: 'admin',
            isVerified: true
        });

        console.log('Admin user created successfully.');
    } catch (error) {
        console.error('Error seeding admin:', error);
    }
};

export default seedAdmin;
