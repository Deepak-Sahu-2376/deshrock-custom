
import { google } from 'googleapis';
import open from 'open';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import express from 'express';

// Load environment variables
dotenv.config();

const CLIENT_ID = process.env.YOUTUBE_CLIENT_ID;
const CLIENT_SECRET = process.env.YOUTUBE_CLIENT_SECRET;
const PORT = 3000;
const REDIRECT_URI = `http://localhost:${PORT}/oauth2callback`;

if (!CLIENT_ID || !CLIENT_SECRET) {
    console.error('Error: YOUTUBE_CLIENT_ID or YOUTUBE_CLIENT_SECRET missing in .env');
    process.exit(1);
}

const oauth2Client = new google.auth.OAuth2(
    CLIENT_ID,
    CLIENT_SECRET,
    REDIRECT_URI
);

// Scopes for YouTube Upload
const SCOPES = [
    'https://www.googleapis.com/auth/youtube.upload',
    'https://www.googleapis.com/auth/youtube.readonly'
];

const app = express();

app.get('/oauth2callback', async (req, res) => {
    const code = req.query.code;

    if (code) {
        console.log(`Code received: ${code}`);
        try {
            const { tokens } = await oauth2Client.getToken(code);

            console.log('\n--- NEW TOKENS (Update your .env with this) ---');
            console.log(`YOUTUBE_REFRESH_TOKEN=${tokens.refresh_token}`);
            console.log('------------------\n');

            if (tokens.refresh_token) {
                res.send('<h1>Authentication successful!</h1><p>Check your terminal for the Refresh Token.</p>');
            } else {
                res.send('<h1>No Refresh Token received.</h1><p>You might need to revoke access to the app in your Google Account settings to force a new refresh token generation.</p>');
            }
            // Close server after a short delay
            setTimeout(() => {
                console.log('Closing server...');
                process.exit(0);
            }, 2000);

        } catch (error) {
            console.error('Error retrieving access token', error);
            res.send('<h1>Error retrieving access token</h1><p>Check terminal logs.</p>');
        }
    } else {
        res.send('Error: No code received');
    }
});

const server = app.listen(PORT, async () => {
    const authUrl = oauth2Client.generateAuthUrl({
        access_type: 'offline',
        scope: SCOPES,
        prompt: 'consent' // Force refresh token
    });

    console.log(`Server listening on port ${PORT}`);
    console.log('Authorize this app by visiting this url:', authUrl);
    await open(authUrl);
});
