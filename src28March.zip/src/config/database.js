import pkg from 'pg';
const { Pool } = pkg;
import dotenv from 'dotenv';
dotenv.config();

const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 10, // max number of connection can be open to database
    idleTimeoutMillis: 30000 // close idle clients after 30 seconds
});

export default pool;
