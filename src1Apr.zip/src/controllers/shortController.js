import db from '../models/index.js';
const { Short: ShortRepository, Property: PropertyRepository } = db;
import { uploadToYouTube } from '../services/youtubeService.js';
import fs from 'fs';
import path from 'path';

/**
 * @desc    Upload a short for a specific property
 * @route   POST /api/v1/shorts/upload/:propertyId
 * @access  Private (Property Owner)
 */
export const uploadShort = async (req, res) => {
    try {
        const { propertyId } = req.params;
        const { title, description } = req.body;
        const videoFile = req.file;

        if (!videoFile) {
            return res.status(400).json({ success: false, message: 'No video file uploaded' });
        }

        // 1. Verify Property and Ownership
        const property = await PropertyRepository.findById(propertyId);
        if (!property) {
            return res.status(404).json({ success: false, message: 'Property not found' });
        }

        // Only owner (userId or company owner) can upload
        // In propertyRepository, userId is the creator.
        if (property.userId !== req.user.id) {
            // Check company ownership if it's a company property
            if (property.companyId) {
                const companyRes = await db.pool.query('SELECT "userId" FROM "CompanyProfiles" WHERE id = $1', [property.companyId]);
                const companyOwner = companyRes.rows[0];
                if (!companyOwner || companyOwner.userId !== req.user.id) {
                    return res.status(403).json({ success: false, message: 'Not authorized to upload shorts for this property' });
                }
            } else {
                return res.status(403).json({ success: false, message: 'Not authorized to upload shorts for this property' });
            }
        }

        // 2. Upload to YouTube
        console.log(`Uploading short for property ${propertyId} to YouTube...`);
        const youtubeVideoId = await uploadToYouTube(
            videoFile.path,
            title || `Short for ${property.title}`,
            description || `Explore this property: ${property.title}. #shorts #realestate`
        );

        if (!youtubeVideoId) {
            return res.status(500).json({ success: false, message: 'YouTube upload failed' });
        }

        // 3. Save to Database
        const newShort = await ShortRepository.create({
            propertyId,
            userId: req.user.id,
            youtubeVideoId,
            title: title || `Short for ${property.title}`,
            description: description || ''
        });

        // 4. Cleanup local file
        fs.unlink(videoFile.path, (err) => {
            if (err) console.error('Error deleting local short video:', err);
        });

        res.status(201).json({
            success: true,
            message: 'Short uploaded successfully',
            data: newShort
        });

    } catch (error) {
        console.error('Error uploading short:', error);
        res.status(500).json({ success: false, message: 'Server error during short upload', error: error.message });
    }
};

/**
 * @desc    Get all active shorts for the main feed
 * @route   GET /api/v1/shorts
 * @access  Public (Optionally Authenticated)
 */
export const getAllShorts = async (req, res) => {
    try {
        const whereClause = {};
        if (req.user && req.user.id) {
            whereClause.contextUserId = req.user.id;
        }
        const shorts = await ShortRepository.findAll(whereClause);
        res.status(200).json({ success: true, count: shorts.length, data: shorts });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error', error: error.message });
    }
};

/**
 * @desc    Get shorts for a specific property
 * @route   GET /api/v1/shorts/property/:propertyId
 * @access  Public (Optionally Authenticated)
 */
export const getPropertyShorts = async (req, res) => {
    try {
        const { propertyId } = req.params;
        const whereClause = { propertyId };
        if (req.user && req.user.id) {
            whereClause.contextUserId = req.user.id;
        }
        const shorts = await ShortRepository.findAll(whereClause);
        res.status(200).json({ success: true, count: shorts.length, data: shorts });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error', error: error.message });
    }
};

/**
 * @desc    Delete a short
 * @route   DELETE /api/v1/shorts/:id
 * @access  Private (Owner/Admin)
 */
export const deleteShort = async (req, res) => {
    try {
        const { id } = req.params;
        const short = await ShortRepository.findById(id);

        if (!short) {
            return res.status(404).json({ success: false, message: 'Short not found' });
        }

        // Auth check
        if (req.user.userType !== 'admin' && short.userId !== req.user.id) {
            return res.status(403).json({ success: false, message: 'Not authorized to delete this short' });
        }

        await ShortRepository.delete(id);
        res.status(200).json({ success: true, message: 'Short deleted successfully' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error', error: error.message });
    }
};

/**
 * @desc    Increment view count for a short
 * @route   PATCH /api/v1/shorts/:id/view
 * @access  Public
 */
export const incrementView = async (req, res) => {
    try {
        const { id } = req.params;
        await ShortRepository.incrementViewCount(id);
        res.status(200).json({ success: true, message: 'View count incremented' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error', error: error.message });
    }
};

/**
 * @desc    Like a short
 * @route   POST /api/v1/shorts/:id/like
 * @access  Private
 */
export const likeShort = async (req, res) => {
    try {
        const { id } = req.params;
        
        // Ensure short exists
        const short = await ShortRepository.findById(id);
        if (!short) {
            return res.status(404).json({ success: false, message: 'Short not found' });
        }

        await db.Like.likeShort(req.user.id, id);
        res.status(200).json({ success: true, message: 'Short liked successfully', liked: true });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error', error: error.message });
    }
};

/**
 * @desc    Unlike a short
 * @route   DELETE /api/v1/shorts/:id/like
 * @access  Private
 */
export const unlikeShort = async (req, res) => {
    try {
        const { id } = req.params;
        
        // Ensure short exists
        const short = await ShortRepository.findById(id);
        if (!short) {
            return res.status(404).json({ success: false, message: 'Short not found' });
        }

        await db.Like.unlikeShort(req.user.id, id);
        res.status(200).json({ success: true, message: 'Short unliked successfully', liked: false });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error', error: error.message });
    }
};

/**
 * @desc    Add a comment to a short
 * @route   POST /api/v1/shorts/:id/comment
 * @access  Private
 */
export const addCommentToShort = async (req, res) => {
    try {
        const { id } = req.params;
        const { text } = req.body;

        if (!text || text.trim() === '') {
            return res.status(400).json({ success: false, message: 'Comment text is required' });
        }

        const short = await ShortRepository.findById(id);
        if (!short) {
            return res.status(404).json({ success: false, message: 'Short not found' });
        }

        const comment = await db.Comment.addComment(req.user.id, id, text);
        res.status(201).json({ success: true, message: 'Comment added', data: comment });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error', error: error.message });
    }
};

/**
 * @desc    Get comments for a short
 * @route   GET /api/v1/shorts/:id/comments
 * @access  Public
 */
export const getShortComments = async (req, res) => {
    try {
        const { id } = req.params;
        
        const short = await ShortRepository.findById(id);
        if (!short) {
            return res.status(404).json({ success: false, message: 'Short not found' });
        }

        const comments = await db.Comment.getCommentsByShortId(id);
        res.status(200).json({ success: true, count: comments.length, data: comments });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error', error: error.message });
    }
};

/**
 * @desc    Get liked shorts for authenticated user
 * @route   GET /api/v1/shorts/liked
 * @access  Private
 */
export const getLikedShorts = async (req, res) => {
    try {
        const shorts = await db.Like.getLikedShortsByUser(req.user.id);
        res.status(200).json({ success: true, count: shorts.length, data: shorts });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error', error: error.message });
    }
};

