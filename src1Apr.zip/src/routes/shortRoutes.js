import express from 'express';
const router = express.Router();
import { uploadShort, getAllShorts, getPropertyShorts, deleteShort, incrementView, likeShort, unlikeShort, addCommentToShort, getShortComments, getLikedShorts } from '../controllers/shortController.js';
import { protect, authorize, optionalProtect } from '../middlewares/authMiddleware.js';
import upload from '../middlewares/uploadMiddleware.js';

// Public routes
router.get('/', optionalProtect, getAllShorts);
router.get('/property/:propertyId', optionalProtect, getPropertyShorts);
router.patch('/:id/view', incrementView);

// Private routes
router.get('/liked', protect, getLikedShorts);

router.post('/upload/:propertyId', protect, upload.single('video'), uploadShort);
router.delete('/:id', protect, deleteShort);

router.post('/:id/like', protect, likeShort);
router.delete('/:id/like', protect, unlikeShort);

router.post('/:id/comment', protect, addCommentToShort);
router.get('/:id/comments', optionalProtect, getShortComments);

export default router;
