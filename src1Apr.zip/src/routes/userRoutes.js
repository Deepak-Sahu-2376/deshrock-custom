import express from 'express';
import { getMe, uploadAvatar, deleteAvatar, followUser, unfollowUser, getUserFollowers, getUserFollowing } from '../controllers/userController.js';
import { protect } from '../middlewares/authMiddleware.js';
import upload from '../middlewares/uploadMiddleware.js';

const router = express.Router();

router.get('/me', protect, getMe);
router.post('/me/avatar', protect, upload.single('file'), uploadAvatar);
router.delete('/me/avatar', protect, deleteAvatar);

router.post('/:id/follow', protect, followUser);
router.delete('/:id/follow', protect, unfollowUser);
router.get('/:id/followers', getUserFollowers);
router.get('/:id/following', getUserFollowing);

export default router;
