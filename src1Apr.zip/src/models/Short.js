import { DataTypes } from 'sequelize';
import pool from '../config/database.js';


const Short = {
    create: async (data) => {
        const { propertyId, userId, youtubeVideoId, title, description } = data;
        const query = `
            INSERT INTO "Shorts" 
            ("propertyId", "userId", "youtubeVideoId", "title", "description", "createdAt", "updatedAt")
            VALUES ($1, $2, $3, $4, $5, NOW(), NOW())
            RETURNING *
        `;
        const { rows } = await pool.query(query, [propertyId, userId, youtubeVideoId, title, description]);
        return rows[0];
    },

    findAll: async (where = {}) => {
        const params = [];
        let paramIndex = 1;

        let query = `
            SELECT s.*, 
                   p.title as "propertyTitle",
                   u."firstName" as "userFirstName", u."lastName" as "userLastName", u.avatar as "userAvatar",
                   (SELECT COUNT(*) FROM "ShortLikes" sl WHERE sl."shortId" = s.id) as "likeCount",
                   (SELECT COUNT(*) FROM "ShortComments" sc WHERE sc."shortId" = s.id) as "commentCount"
        `;

        if (where.contextUserId) {
            query += `, (SELECT EXISTS(SELECT 1 FROM "ShortLikes" sl WHERE sl."shortId" = s.id AND sl."userId" = $${paramIndex})) as "isLiked"`;
            params.push(where.contextUserId);
            paramIndex++;
        }

        query += `
            FROM "Shorts" s
            JOIN "Properties" p ON s."propertyId" = p.id
            JOIN "Users" u ON s."userId" = u.id
            WHERE s."isActive" = true
        `;

        if (where.propertyId) {
            query += ` AND s."propertyId" = $${paramIndex}`;
            params.push(where.propertyId);
            paramIndex++;
        }
        
        query += ` ORDER BY s."createdAt" DESC`;
        const { rows } = await pool.query(query, params);
        
        // Convert counts to integers (pg returns COUNT as string)
        return rows.map(row => ({
            ...row,
            likeCount: parseInt(row.likeCount || '0', 10),
            commentCount: parseInt(row.commentCount || '0', 10)
        }));
    },

    findById: async (id, contextUserId = null) => {
        const params = [id];
        let paramIndex = 2;

        let query = `
            SELECT s.*, 
                   p.title as "propertyTitle",
                   u."firstName" as "userFirstName", u."lastName" as "userLastName", u.avatar as "userAvatar",
                   (SELECT COUNT(*) FROM "ShortLikes" sl WHERE sl."shortId" = s.id) as "likeCount",
                   (SELECT COUNT(*) FROM "ShortComments" sc WHERE sc."shortId" = s.id) as "commentCount"
        `;

        if (contextUserId) {
            query += `, (SELECT EXISTS(SELECT 1 FROM "ShortLikes" sl WHERE sl."shortId" = s.id AND sl."userId" = $${paramIndex})) as "isLiked"`;
            params.push(contextUserId);
        }

        query += `
            FROM "Shorts" s
            JOIN "Properties" p ON s."propertyId" = p.id
            JOIN "Users" u ON s."userId" = u.id
            WHERE s.id = $1
        `;

        const { rows } = await pool.query(query, params);
        
        if (rows[0]) {
            rows[0].likeCount = parseInt(rows[0].likeCount || '0', 10);
            rows[0].commentCount = parseInt(rows[0].commentCount || '0', 10);
        }
        
        return rows[0];
    },

    delete: async (id) => {
        const query = `DELETE FROM "Shorts" WHERE id = $1 RETURNING *`;
        const { rows } = await pool.query(query, [id]);
        return rows[0];
    },

    incrementViewCount: async (id) => {
        const query = `UPDATE "Shorts" SET "viewCount" = "viewCount" + 1, "updatedAt" = NOW() WHERE id = $1 RETURNING *`;
        const { rows } = await pool.query(query, [id]);
        return rows[0];
    }
};

export default Short;
