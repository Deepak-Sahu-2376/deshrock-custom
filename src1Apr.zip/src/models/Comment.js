import pool from '../config/database.js';

const Comment = {
    addComment: async (userId, shortId, text) => {
        const query = `
            INSERT INTO "ShortComments" ("userId", "shortId", "text", "createdAt", "updatedAt")
            VALUES ($1, $2, $3, NOW(), NOW())
            RETURNING *
        `;
        const { rows } = await pool.query(query, [userId, shortId, text]);
        return rows[0];
    },

    getCommentsByShortId: async (shortId) => {
        const query = `
            SELECT sc.*, 
                   u."firstName", u."lastName", u.avatar
            FROM "ShortComments" sc
            JOIN "Users" u ON sc."userId" = u.id
            WHERE sc."shortId" = $1
            ORDER BY sc."createdAt" DESC
        `;
        const { rows } = await pool.query(query, [shortId]);
        return rows;
    },

    deleteComment: async (id) => {
        const query = `
            DELETE FROM "ShortComments" WHERE id = $1 RETURNING *
        `;
        const { rows } = await pool.query(query, [id]);
        return rows[0];
    }
};

export default Comment;
