import pool from '../config/database.js';

const Follower = {
    followUser: async (followerId, followingId) => {
        const query = `
            INSERT INTO "UserFollowers" ("followerId", "followingId", "createdAt")
            VALUES ($1, $2, NOW())
            ON CONFLICT ("followerId", "followingId") DO NOTHING
            RETURNING *
        `;
        const { rows } = await pool.query(query, [followerId, followingId]);
        return rows[0];
    },

    unfollowUser: async (followerId, followingId) => {
        const query = `
            DELETE FROM "UserFollowers"
            WHERE "followerId" = $1 AND "followingId" = $2
            RETURNING *
        `;
        const { rows } = await pool.query(query, [followerId, followingId]);
        return rows[0];
    },

    checkIsFollowing: async (followerId, followingId) => {
        const query = `
            SELECT 1 FROM "UserFollowers"
            WHERE "followerId" = $1 AND "followingId" = $2
        `;
        const { rows } = await pool.query(query, [followerId, followingId]);
        return rows.length > 0;
    },

    getFollowers: async (userId) => {
        const query = `
            SELECT uf.*, 
                   u."firstName", u."lastName", u.avatar
            FROM "UserFollowers" uf
            JOIN "Users" u ON uf."followerId" = u.id
            WHERE uf."followingId" = $1
            ORDER BY uf."createdAt" DESC
        `;
        const { rows } = await pool.query(query, [userId]);
        return rows;
    },

    getFollowing: async (userId) => {
        const query = `
            SELECT uf.*, 
                   u."firstName", u."lastName", u.avatar
            FROM "UserFollowers" uf
            JOIN "Users" u ON uf."followingId" = u.id
            WHERE uf."followerId" = $1
            ORDER BY uf."createdAt" DESC
        `;
        const { rows } = await pool.query(query, [userId]);
        return rows;
    }
};

export default Follower;
