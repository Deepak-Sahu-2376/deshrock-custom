import pool from '../config/database.js';

const Like = {
    likeShort: async (userId, shortId) => {
        const query = `
            INSERT INTO "ShortLikes" ("userId", "shortId", "createdAt")
            VALUES ($1, $2, NOW())
            ON CONFLICT ("userId", "shortId") DO NOTHING
            RETURNING *
        `;
        const { rows } = await pool.query(query, [userId, shortId]);
        return rows[0];
    },

    unlikeShort: async (userId, shortId) => {
        const query = `
            DELETE FROM "ShortLikes"
            WHERE "userId" = $1 AND "shortId" = $2
            RETURNING *
        `;
        const { rows } = await pool.query(query, [userId, shortId]);
        return rows[0];
    },

    checkUserLiked: async (userId, shortId) => {
        const query = `
            SELECT 1 FROM "ShortLikes"
            WHERE "userId" = $1 AND "shortId" = $2
        `;
        const { rows } = await pool.query(query, [userId, shortId]);
        return rows.length > 0;
    },

    getLikedShortsByUser: async (userId) => {
        const query = `
            SELECT s.*, 
                   p.title as "propertyTitle",
                   u."firstName" as "userFirstName", u."lastName" as "userLastName", u.avatar as "userAvatar"
            FROM "ShortLikes" sl
            JOIN "Shorts" s ON sl."shortId" = s.id
            JOIN "Properties" p ON s."propertyId" = p.id
            JOIN "Users" u ON s."userId" = u.id
            WHERE sl."userId" = $1 AND s."isActive" = true
            ORDER BY sl."createdAt" DESC
        `;
        const { rows } = await pool.query(query, [userId]);
        return rows;
    }
};

export default Like;
