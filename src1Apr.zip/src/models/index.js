import pool from '../config/database.js';

// Import Repositories
import UserRepository from './User.js';
import CompanyProfileRepository from './CompanyProfile.js';
import AgentProfileRepository from './AgentProfile.js';
import OtpRepository from './Otp.js';
import PropertyRepository from './Property.js';
import ProjectRepository from './Project.js';
import DocumentRepository from './Document.js';
import VisitRepository from './Visit.js';
import InquiryRepository from './Inquiry.js';
import PhaseRepository from './Phase.js';
import ShortRepository from './Short.js';
import LikeRepository from './Like.js';
import CommentRepository from './Comment.js';
import FollowerRepository from './Follower.js';

const db = {
    pool, // Expose pool directly if needed
    User: UserRepository,
    CompanyProfile: CompanyProfileRepository,
    AgentProfile: AgentProfileRepository,
    Otp: OtpRepository,
    Property: PropertyRepository,
    Project: ProjectRepository,
    Document: DocumentRepository,
    Inquiry: InquiryRepository,
    Visit: VisitRepository,
    Phase: PhaseRepository,
    Short: ShortRepository,
    Like: LikeRepository,
    Comment: CommentRepository,
    Follower: FollowerRepository
};

// With pg, associations are handled via SQL JOINs in repositories/controllers
// The ORM associations are no longer needed here.

export default db;
