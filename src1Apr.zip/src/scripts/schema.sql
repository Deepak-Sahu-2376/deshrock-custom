-- 1. Users Table
CREATE TABLE IF NOT EXISTS "Users" (
    "id" SERIAL PRIMARY KEY,
    "email" VARCHAR(255) NOT NULL UNIQUE,
    "identifier" VARCHAR(255) NOT NULL UNIQUE,
    "password" VARCHAR(255) NOT NULL,
    "firstName" VARCHAR(255) NOT NULL,
    "lastName" VARCHAR(255) NOT NULL,
    "phone" VARCHAR(255),
    "userType" VARCHAR(50) DEFAULT 'buyer' CHECK ("userType" IN ('admin', 'buyer', 'agent', 'company', 'company_agent')),
    "isVerified" BOOLEAN DEFAULT FALSE,
    "avatar" VARCHAR(255),
    "acceptTerms" BOOLEAN DEFAULT FALSE,
    "acceptPrivacyPolicy" BOOLEAN DEFAULT FALSE,
    "allowMarketingEmails" BOOLEAN DEFAULT FALSE,
    "allowSmsNotifications" BOOLEAN DEFAULT FALSE,
    "profileComplete" BOOLEAN DEFAULT FALSE,
    "createdAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 2. CompanyProfiles Table
CREATE TABLE IF NOT EXISTS "CompanyProfiles" (
    "id" SERIAL PRIMARY KEY,
    "userId" INTEGER NOT NULL UNIQUE REFERENCES "Users"("id") ON DELETE CASCADE,
    "companyName" VARCHAR(255) NOT NULL,
    "companyType" VARCHAR(255),
    "registrationNumber" VARCHAR(255),
    "establishmentYear" INTEGER,
    "contactPersonName" VARCHAR(255),
    "contactPersonDesignation" VARCHAR(255),
    "alternateEmail" VARCHAR(255),
    "address" TEXT,
    "city" VARCHAR(255),
    "state" VARCHAR(255),
    "country" VARCHAR(255),
    "pincode" VARCHAR(255),
    "description" TEXT,
    "serviceAreas" VARCHAR(255)[] DEFAULT '{}',
    "specializations" VARCHAR(255)[] DEFAULT '{}',
    "gstNumber" VARCHAR(255),
    "panNumber" VARCHAR(255),
    "licenseNumber" VARCHAR(255),
    "licenseAuthority" VARCHAR(255),
    "licenseExpiryDate" DATE,
    "website" VARCHAR(255),
    "employeeCount" INTEGER DEFAULT 0,
    "status" VARCHAR(50) DEFAULT 'pending' CHECK ("status" IN ('pending', 'approved', 'rejected')),
    "createdAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 3. AgentProfiles Table
CREATE TABLE IF NOT EXISTS "AgentProfiles" (
    "id" SERIAL PRIMARY KEY,
    "userId" INTEGER NOT NULL UNIQUE REFERENCES "Users"("id") ON DELETE CASCADE,
    "city" VARCHAR(255),
    "state" VARCHAR(255),
    "country" VARCHAR(255),
    "address" TEXT,
    "pincode" VARCHAR(255),
    "specialization" VARCHAR(255),
    "experienceYears" REAL DEFAULT 0,
    "bio" TEXT,
    "serviceAreas" VARCHAR(255)[] DEFAULT '{}',
    "languages" VARCHAR(255)[] DEFAULT '{}',
    "dob" DATE,
    "agentType" VARCHAR(50) DEFAULT 'INDIVIDUAL' CHECK ("agentType" IN ('INDIVIDUAL', 'COMPANY_AGENT')),
    "companyId" INTEGER REFERENCES "CompanyProfiles"("id") ON DELETE SET NULL,
    "companyName" VARCHAR(255),
    "profileVisibility" BOOLEAN DEFAULT TRUE,
    "status" VARCHAR(50) DEFAULT 'pending' CHECK ("status" IN ('pending', 'pending_company_approval', 'approved', 'rejected')),
    "createdAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 4. Otps Table
CREATE TABLE IF NOT EXISTS "Otps" (
    "id" SERIAL PRIMARY KEY,
    "identifier" VARCHAR(255) NOT NULL,
    "code" VARCHAR(255) NOT NULL,
    "expiresAt" TIMESTAMP WITH TIME ZONE NOT NULL,
    "isUsed" BOOLEAN DEFAULT FALSE,
    "purpose" VARCHAR(255) DEFAULT 'registration',
    "createdAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 5. Properties Table
CREATE TABLE IF NOT EXISTS "Properties" (
    "id" SERIAL PRIMARY KEY,
    "companyId" INTEGER REFERENCES "CompanyProfiles"("id") ON DELETE SET NULL,
    "userId" INTEGER REFERENCES "Users"("id") ON DELETE SET NULL,
    "title" VARCHAR(255) NOT NULL,
    "description" TEXT NOT NULL,
    "propertyType" VARCHAR(50) NOT NULL CHECK ("propertyType" IN ('APARTMENT', 'VILLA', 'PLOT', 'COMMERCIAL')),
    "listingType" VARCHAR(50) NOT NULL CHECK ("listingType" IN ('SALE', 'RENT', 'PG', 'COMMERCIAL_RENT')),
    "status" VARCHAR(50) DEFAULT 'PENDING' CHECK ("status" IN ('PENDING', 'APPROVED', 'REJECTED', 'PENDING_COMPANY')),
    "rejectionReason" TEXT,
    "bedrooms" INTEGER,
    "bathrooms" INTEGER,
    "balconies" INTEGER,
    "furnishingStatus" VARCHAR(50) DEFAULT 'UNFURNISHED' CHECK ("furnishingStatus" IN ('FULLY_FURNISHED', 'SEMI_FURNISHED', 'UNFURNISHED')),
    "pantry" BOOLEAN DEFAULT FALSE,
    "washroom" BOOLEAN DEFAULT FALSE,
    "carpetArea" REAL NOT NULL,
    "builtUpArea" REAL,
    "superBuiltUpArea" REAL,
    "floorNumber" INTEGER,
    "totalFloors" INTEGER,
    "unitNumber" VARCHAR(255),
    "tower" VARCHAR(255),
    "isCornerUnit" BOOLEAN DEFAULT FALSE,
    "basePrice" NUMERIC(15, 2),
    "monthlyRent" NUMERIC(15, 2),
    "securityDeposit" NUMERIC(15, 2),
    "maintenanceCharges" NUMERIC(15, 2),
    "floorRiseCharges" NUMERIC(15, 2) DEFAULT 0,
    "coveredParkingSpots" INTEGER DEFAULT 0,
    "openParkingSpots" INTEGER DEFAULT 0,
    "address" TEXT NOT NULL,
    "city" VARCHAR(255) NOT NULL,
    "state" VARCHAR(255) NOT NULL,
    "pincode" VARCHAR(255) NOT NULL,
    "country" VARCHAR(255) DEFAULT 'India',
    "latitude" REAL,
    "longitude" REAL,
    "amenities" VARCHAR(255)[] DEFAULT '{}',
    "images" VARCHAR(255)[] DEFAULT '{}',
    "video" VARCHAR(255),
    "floorPlan" VARCHAR(255),
    "isFeatured" BOOLEAN DEFAULT FALSE,
    "viewCount" INTEGER DEFAULT 0,
    "createdAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 6. Projects Table
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS "Projects" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "companyId" INTEGER NOT NULL REFERENCES "CompanyProfiles"("id") ON DELETE CASCADE,
    "name" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "projectType" VARCHAR(255) NOT NULL,
    "status" VARCHAR(50) DEFAULT 'UNDER_CONSTRUCTION' CHECK ("status" IN ('UPCOMING', 'UNDER_CONSTRUCTION', 'READY_TO_MOVE', 'COMPLETED')),
    "approvalStatus" VARCHAR(50) DEFAULT 'PENDING' CHECK ("approvalStatus" IN ('PENDING', 'APPROVED', 'REJECTED')),
    "isActive" BOOLEAN DEFAULT TRUE,
    "isFeatured" BOOLEAN DEFAULT FALSE,
    "developerName" VARCHAR(255),
    "architectName" VARCHAR(255),
    "totalPhases" INTEGER DEFAULT 1,
    "totalTowers" INTEGER DEFAULT 0,
    "totalFloors" INTEGER DEFAULT 0,
    "totalUnits" INTEGER DEFAULT 0,
    "availableUnits" INTEGER DEFAULT 0,
    "totalArea" REAL,
    "startingPrice" NUMERIC(15, 2),
    "priceRangeMax" NUMERIC(15, 2),
    "avgPrice" NUMERIC(15, 2),
    "pricePerSqft" NUMERIC(10, 2),
    "launchDate" DATE,
    "possessionDate" DATE,
    "expectedCompletion" DATE,
    "address" TEXT,
    "city" VARCHAR(255),
    "state" VARCHAR(255),
    "pincode" VARCHAR(255),
    "country" VARCHAR(255) DEFAULT 'India',
    "latitude" REAL,
    "longitude" REAL,
    "locationAdvantages" VARCHAR(255)[] DEFAULT '{}',
    "reraApproved" BOOLEAN DEFAULT FALSE,
    "reraNumber" VARCHAR(255),
    "reraValidityDate" DATE,
    "amenities" VARCHAR(255)[] DEFAULT '{}',
    "media" JSONB DEFAULT '[]'::jsonb,
    "createdAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 7. Phases Table
CREATE TABLE IF NOT EXISTS "Phases" (
    "id" SERIAL PRIMARY KEY,
    "projectId" UUID NOT NULL REFERENCES "Projects"("id") ON DELETE CASCADE,
    "name" VARCHAR(255) NOT NULL,
    "phaseNumber" INTEGER,
    "status" VARCHAR(255) DEFAULT 'PLANNING',
    "constructionStatus" VARCHAR(255),
    "reraNumber" VARCHAR(255),
    "description" TEXT,
    "totalUnits" INTEGER DEFAULT 0,
    "bookedUnits" INTEGER DEFAULT 0,
    "soldUnits" INTEGER DEFAULT 0,
    "availableUnits" INTEGER DEFAULT 0,
    "startingPrice" NUMERIC(15, 2),
    "completionPercentage" INTEGER DEFAULT 0,
    "approvedAt" TIMESTAMP WITH TIME ZONE,
    "phaseLogoUrl" VARCHAR(255),
    "phaseBrochureUrl" VARCHAR(255),
    "masterPlanUrl" VARCHAR(255),
    "floorPlanUrls" JSON DEFAULT '[]'::json,
    "specifications" TEXT,
    "createdAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 8. Visits Table
CREATE TABLE IF NOT EXISTS "Visits" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "userId" INTEGER NOT NULL REFERENCES "Users"("id") ON DELETE CASCADE,
    "propertyId" INTEGER NOT NULL REFERENCES "Properties"("id") ON DELETE CASCADE,
    "agentId" INTEGER REFERENCES "Users"("id") ON DELETE SET NULL,
    "preferredVisitTime" TIMESTAMP WITH TIME ZONE NOT NULL,
    "status" VARCHAR(50) DEFAULT 'PENDING' CHECK ("status" IN ('PENDING', 'CONFIRMED', 'CANCELLED', 'COMPLETED')),
    "message" TEXT,
    "adminNotes" TEXT,
    "createdAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 9. Documents Table
CREATE TABLE IF NOT EXISTS "Documents" (
    "id" SERIAL PRIMARY KEY,
    "entityId" INTEGER NOT NULL,
    "entityType" VARCHAR(50) NOT NULL CHECK ("entityType" IN ('USER', 'COMPANY', 'AGENT', 'PROPERTY', 'PROJECT')),
    "documentType" VARCHAR(255),
    "fileName" VARCHAR(255) NOT NULL,
    "fileUrl" VARCHAR(255) NOT NULL,
    "mimeType" VARCHAR(255),
    "fileSize" INTEGER,
    "status" VARCHAR(50) DEFAULT 'PENDING' CHECK ("status" IN ('PENDING', 'VERIFIED', 'REJECTED')),
    "createdAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 10. Inquiries Table
CREATE TABLE IF NOT EXISTS "Inquiries" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "propertyId" INTEGER REFERENCES "Properties"("id") ON DELETE SET NULL,
    "projectId" UUID REFERENCES "Projects"("id") ON DELETE SET NULL,
    "userId" INTEGER,
    "name" VARCHAR(255) NOT NULL,
    "email" VARCHAR(255) NOT NULL,
    "phone" VARCHAR(255) NOT NULL,
    "message" TEXT NOT NULL,
    "status" VARCHAR(50) DEFAULT 'PENDING' CHECK ("status" IN ('PENDING', 'CONTACTED', 'RESOLVED', 'SPAM')),
    "createdAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Create Indexes
CREATE INDEX idx_properties_company_id ON "Properties"("companyId");
CREATE INDEX idx_properties_status ON "Properties"("status");
CREATE INDEX idx_properties_city ON "Properties"("city");
CREATE INDEX idx_properties_type ON "Properties"("propertyType");
CREATE INDEX idx_properties_listing ON "Properties"("listingType");

CREATE INDEX idx_projects_company_id ON "Projects"("companyId");
CREATE INDEX idx_projects_city ON "Projects"("city");
CREATE INDEX idx_projects_type ON "Projects"("projectType");
CREATE INDEX idx_projects_status ON "Projects"("status");

CREATE INDEX idx_visits_user_id ON "Visits"("userId");
CREATE INDEX idx_visits_agent_id ON "Visits"("agentId");
CREATE INDEX idx_visits_property_id ON "Visits"("propertyId");
CREATE INDEX idx_visits_status ON "Visits"("status");
CREATE INDEX idx_visits_time ON "Visits"("preferredVisitTime");
-- 11. Shorts Table
CREATE TABLE IF NOT EXISTS "Shorts" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "propertyId" INTEGER NOT NULL REFERENCES "Properties"("id") ON DELETE CASCADE,
    "userId" INTEGER NOT NULL REFERENCES "Users"("id") ON DELETE CASCADE,
    "youtubeVideoId" VARCHAR(255) NOT NULL,
    "title" VARCHAR(255),
    "description" TEXT,
    "viewCount" INTEGER DEFAULT 0,
    "isActive" BOOLEAN DEFAULT TRUE,
    "createdAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Create Indexes for Shorts
CREATE INDEX idx_shorts_property_id ON "Shorts"("propertyId");
CREATE INDEX idx_shorts_user_id ON "Shorts"("userId");
CREATE INDEX idx_shorts_is_active ON "Shorts"("isActive");

-- 12. ShortLikes Table
CREATE TABLE IF NOT EXISTS "ShortLikes" (
    "userId" INTEGER NOT NULL REFERENCES "Users"("id") ON DELETE CASCADE,
    "shortId" UUID NOT NULL REFERENCES "Shorts"("id") ON DELETE CASCADE,
    "createdAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    PRIMARY KEY ("userId", "shortId")
);

-- 13. ShortComments Table
CREATE TABLE IF NOT EXISTS "ShortComments" (
    "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "userId" INTEGER NOT NULL REFERENCES "Users"("id") ON DELETE CASCADE,
    "shortId" UUID NOT NULL REFERENCES "Shorts"("id") ON DELETE CASCADE,
    "text" TEXT NOT NULL,
    "createdAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    "updatedAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_short_comments_short_id ON "ShortComments"("shortId");
CREATE INDEX idx_short_comments_user_id ON "ShortComments"("userId");

-- 14. UserFollowers Table
CREATE TABLE IF NOT EXISTS "UserFollowers" (
    "followerId" INTEGER NOT NULL REFERENCES "Users"("id") ON DELETE CASCADE,
    "followingId" INTEGER NOT NULL REFERENCES "Users"("id") ON DELETE CASCADE,
    "createdAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    PRIMARY KEY ("followerId", "followingId"),
    CHECK ("followerId" != "followingId")
);
CREATE INDEX idx_user_followers_following_id ON "UserFollowers"("followingId");
CREATE INDEX idx_user_followers_follower_id ON "UserFollowers"("followerId");

